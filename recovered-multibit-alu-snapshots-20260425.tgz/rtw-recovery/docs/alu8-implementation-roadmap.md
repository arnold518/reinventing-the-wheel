# 8-Bit ALU Implementation Roadmap

**Last Updated**: January 2026
**Status**: Phase 7 - Integration Ready
**Target**: Fully functional gate-level 8-bit Arithmetic Logic Unit

---

## Table of Contents

1. [Overview](#overview)
2. [Completed Components](#completed-components)
3. [ALU8 Specification](#alu8-specification)
4. [Internal Architecture](#internal-architecture)
5. [Implementation Plan](#implementation-plan)
6. [Testing Strategy](#testing-strategy)

---

## Overview

This document specifies the ALU8 component - a fully functional 8-bit Arithmetic Logic Unit built from gate-level components. The design prioritizes educational value and visualization over optimization.

**Design Philosophy:**
- All operations computed in parallel by dedicated functional units
- Large output multiplexer selects result based on opcode
- Flag logic computed from selected result
- No shared/optimized paths - each operation has its own hardware

---

## Completed Components

### Phase 1: Logic Operations ✓
| Component | Function | Inputs | Outputs |
|-----------|----------|--------|---------|
| AND8 | A & B | A<8>, B<8> | OUT<8> |
| OR8 | A \| B | A<8>, B<8> | OUT<8> |
| XOR8 | A ^ B | A<8>, B<8> | OUT<8> |
| NOT8 | ~A | A<8> | OUT<8> |
| NAND8 | ~(A & B) | A<8>, B<8> | OUT<8> |
| NOR8 | ~(A \| B) | A<8>, B<8> | OUT<8> |

### Phase 2: Multiplexers ✓
| Component | Function | Select Bits |
|-----------|----------|-------------|
| Mux2to1 | 2:1 select | 1 |
| Mux4to1 | 4:1 select | 2 |
| Mux8to1 | 8:1 select | 3 |
| Mux2to1_8bit | 8-bit 2:1 | 1 |
| Mux4to1_8bit | 8-bit 4:1 | 2 |
| Mux8to1_8bit | 8-bit 8:1 | 3 |

### Phase 3: Arithmetic Operations ✓
| Component | Function | Inputs | Outputs |
|-----------|----------|--------|---------|
| Adder8 | A + B + Cin | A<8>, B<8>, Cin | Sum<8>, Cout |
| Subtractor8 | A - B | A<8>, B<8> | Result<8>, Bout, Overflow |
| SubtractorWithBorrow8 | A - B - Bin | A<8>, B<8>, Bin | Result<8>, Bout, Overflow |
| Incrementer8 | A + 1 | A<8>, B<8>=0, Cin=1 | Result<8>, Cout, Overflow |
| Decrementer8 | A - 1 | A<8>, B<8>=0, Bin=1 | Result<8>, Bout, Overflow |
| TwosComplement8 | -A | A<8>, B<8>=0, Cin=1 | Result<8>, Cout, Overflow |

### Phase 4: Comparison Operations ✓
| Component | Function | Inputs | Outputs |
|-----------|----------|--------|---------|
| EqualityChecker8 | A == B | A<8>, B<8> | EQ |
| Comparator8 | Unsigned compare | A<8>, B<8> | LT, GT, EQ |
| SignedComparator8 | Signed compare | A<8>, B<8> | SLT, SGT, SEQ |

### Phase 5: Shift Operations ✓
| Component | Function | Inputs | Outputs |
|-----------|----------|--------|---------|
| ShiftLeftLogical8 | A << 1 | A<8> | Result<8>, Carry |
| ShiftRightLogical8 | A >> 1 | A<8> | Result<8>, Carry |
| ShiftRightArithmetic8 | A >> 1 (sign ext) | A<8> | Result<8>, Carry |

### Utility Components ✓
| Component | Function |
|-----------|----------|
| Ground | Constant LOW output |
| BitSplitter<8> | Split 8-bit to 8× 1-bit |
| BitJoiner<8> | Join 8× 1-bit to 8-bit |

---

## ALU8 Specification

### External Interface

```
                    ┌─────────────────────┐
        A<8> ──────►│                     │──────► Result<8>
        B<8> ──────►│       ALU8          │──────► Zero
        Op<4> ─────►│                     │──────► Carry
                    │                     │──────► Overflow
                    │                     │──────► Negative
                    └─────────────────────┘
```

### Inputs

| Pin | Width | Description |
|-----|-------|-------------|
| A | 8 | First operand |
| B | 8 | Second operand |
| Op | 4 | Operation select (0-15) |

### Outputs

| Pin | Width | Description |
|-----|-------|-------------|
| Result | 8 | Operation result |
| Zero | 1 | HIGH if Result == 0x00 |
| Carry | 1 | Carry/borrow out (arithmetic/shift) |
| Overflow | 1 | Signed overflow (arithmetic only) |
| Negative | 1 | Sign bit (Result[7]) |

### Operation Encoding (4-bit Opcode)

| Op[3:0] | Mnemonic | Function | Component Used | Flags |
|---------|----------|----------|----------------|-------|
| 0000 | ADD | A + B | Adder8 | Z,C,V,N |
| 0001 | SUB | A - B | Subtractor8 | Z,C,V,N |
| 0010 | AND | A & B | AND8 | Z,N |
| 0011 | OR | A \| B | OR8 | Z,N |
| 0100 | XOR | A ^ B | XOR8 | Z,N |
| 0101 | NOT | ~A | NOT8 | Z,N |
| 0110 | SLL | A << 1 | ShiftLeftLogical8 | Z,C,N |
| 0111 | SRL | A >> 1 | ShiftRightLogical8 | Z,C,N |
| 1000 | SRA | A >> 1 (arith) | ShiftRightArithmetic8 | Z,C,N |
| 1001 | SLT | A < B ? 1 : 0 (signed) | SignedComparator8 | Z,N |
| 1010 | SLTU | A < B ? 1 : 0 (unsigned) | Comparator8 | Z,N |
| 1011 | INC | A + 1 | Incrementer8 | Z,C,V,N |
| 1100 | DEC | A - 1 | Decrementer8 | Z,C,V,N |
| 1101 | NEG | -A (two's complement) | TwosComplement8 | Z,C,V,N |
| 1110 | NAND | ~(A & B) | NAND8 | Z,N |
| 1111 | NOR | ~(A \| B) | NOR8 | Z,N |

### Flag Behavior

| Flag | Set When | Operations |
|------|----------|------------|
| Zero (Z) | Result == 0x00 | All |
| Carry (C) | Unsigned overflow/shift-out | ADD, SUB, INC, DEC, NEG, SLL, SRL, SRA |
| Overflow (V) | Signed overflow | ADD, SUB, INC, DEC, NEG |
| Negative (N) | Result[7] == 1 | All |

**Carry semantics:**
- ADD: Carry out of bit 7
- SUB/DEC: Borrow (inverted carry) - HIGH if no borrow occurred
- INC/NEG: Carry out
- SLL: Bit shifted out (A[7])
- SRL/SRA: Bit shifted out (A[0])

**Overflow semantics:**
- ADD: (A[7] == B[7]) && (Result[7] != A[7])
- SUB: (A[7] != B[7]) && (Result[7] != A[7])

---

## Internal Architecture

### Block Diagram

```
                                A<8>                    B<8>
                                  │                       │
                    ┌─────────────┼───────────────────────┼─────────────┐
                    │             │                       │             │
                    │   ┌─────────┴─────────┐   ┌────────┴────────┐   │
                    │   │   A Distribution  │   │  B Distribution │   │
                    │   │   (fan-out to     │   │  (fan-out to    │   │
                    │   │    all units)     │   │   logic/arith)  │   │
                    │   └─────────┬─────────┘   └────────┬────────┘   │
                    │             │                       │             │
        ┌───────────┼─────────────┼───────────────────────┼─────────────┤
        │           │             │                       │             │
        │  ┌────────▼────────┐   │                       │             │
        │  │ Constant Sources│   │                       │             │
        │  │ GND<8>, GND, VCC│   │                       │             │
        │  └────────┬────────┘   │                       │             │
        │           │             │                       │             │
┌───────┼───────────┼─────────────┼───────────────────────┼─────────────┤
│       │           │             │                       │             │
│   ┌───▼───┐   ┌───▼───┐   ┌────▼────┐   ┌─────▼─────┐  │             │
│   │Adder8 │   │ Sub8  │   │  AND8   │   │   OR8     │  │             │
│   │A+B    │   │A-B    │   │  A&B    │   │  A|B      │  │             │
│   └───┬───┘   └───┬───┘   └────┬────┘   └─────┬─────┘  │             │
│       │           │            │              │         │             │
│   ┌───▼───┐   ┌───▼───┐   ┌────▼────┐   ┌─────▼─────┐  │             │
│   │ XOR8  │   │ NOT8  │   │  SLL8   │   │   SRL8    │  │             │
│   │ A^B   │   │  ~A   │   │  A<<1   │   │   A>>1    │  │             │
│   └───┬───┘   └───┬───┘   └────┬────┘   └─────┬─────┘  │             │
│       │           │            │              │         │             │
│   ┌───▼───┐   ┌───▼───┐   ┌────▼────┐   ┌─────▼─────┐  │             │
│   │ SRA8  │   │SignCmp│   │  UsCmp  │   │   INC8    │  │             │
│   │A>>1(a)│   │ SLT   │   │  SLTU   │   │   A+1     │  │             │
│   └───┬───┘   └───┬───┘   └────┬────┘   └─────┬─────┘  │             │
│       │           │            │              │         │             │
│   ┌───▼───┐   ┌───▼───┐   ┌────▼────┐   ┌─────▼─────┐  │             │
│   │ DEC8  │   │ NEG8  │   │  NAND8  │   │   NOR8    │  │             │
│   │ A-1   │   │  -A   │   │~(A&B)   │   │ ~(A|B)    │  │             │
│   └───┬───┘   └───┬───┘   └────┬────┘   └─────┬─────┘  │             │
│       │           │            │              │         │             │
└───────┼───────────┼────────────┼──────────────┼─────────┘             │
        │           │            │              │                       │
        └───────────┴────────────┴──────────────┘                       │
                              │                                         │
                    ┌─────────▼─────────┐                               │
                    │                   │                               │
                    │  Result Mux 16:1  │◄──────────────────────────────┘
                    │    (8-bit wide)   │                    Op<4>
                    │                   │
                    └─────────┬─────────┘
                              │
                    ┌─────────▼─────────┐
                    │   Flag Logic      │
                    │  Z = NOR(Result)  │
                    │  N = Result[7]    │
                    │  C = Mux(carries) │
                    │  V = Mux(overflows│
                    └─────────┬─────────┘
                              │
              ┌───────┬───────┼───────┬───────┐
              │       │       │       │       │
              ▼       ▼       ▼       ▼       ▼
           Result<8> Zero   Carry Overflow Negative
```

### Result Multiplexer Structure

We need a 16:1 8-bit multiplexer. Build from existing components:

```
        Results 0-7              Results 8-15
             │                        │
      ┌──────▼──────┐          ┌──────▼──────┐
      │ Mux8to1_8bit│          │ Mux8to1_8bit│
      │   (LOW)     │          │   (HIGH)    │
      └──────┬──────┘          └──────┬──────┘
             │                        │
             │    Op[2:0]             │    Op[2:0]
             │       │                │       │
             └───────┼────────────────┘       │
                     │                        │
              ┌──────▼──────┐                 │
              │ Mux2to1_8bit│◄────────────────┘
              │             │         Op[3]
              └──────┬──────┘
                     │
                     ▼
                  Result<8>
```

### Carry/Overflow Multiplexer

Different operations produce different carry/overflow signals:

| Op | Carry Source | Overflow Source |
|----|--------------|-----------------|
| ADD | Adder8.Cout | Adder8 overflow logic |
| SUB | Subtractor8.Bout | Subtractor8.Overflow |
| SLL | ShiftLeftLogical8.Carry | 0 |
| SRL | ShiftRightLogical8.Carry | 0 |
| SRA | ShiftRightArithmetic8.Carry | 0 |
| INC | Incrementer8.Cout | Incrementer8.Overflow |
| DEC | Decrementer8.Bout | Decrementer8.Overflow |
| NEG | TwosComplement8.Cout | TwosComplement8.Overflow |
| Others | 0 | 0 |

Use Mux16to1 (single-bit) to select carry and overflow based on Op.

### Constant Sources

Some operations need fixed inputs:

| Component | B Input | Cin/Bin Input |
|-----------|---------|---------------|
| Adder8 | External B | Ground (0) |
| Subtractor8 | External B | N/A |
| Incrementer8 | Ground8 (0x00) | Vcc (1) |
| Decrementer8 | Ground8 (0x00) | Vcc (1) |
| TwosComplement8 | Ground8 (0x00) | Vcc (1) |

Create:
- `Ground8`: 8-bit constant 0x00 (8× Ground in parallel, joined)
- `Vcc`: Constant HIGH output (inverse of Ground, or dedicated component)

### SLT/SLTU Result Generation

Comparators output LT flags, but we need 8-bit results (0x00 or 0x01):

```
SignedComparator8.SLT ──► BitJoiner<8> ──► SLT_Result<8>
                              │
                         IN_0 = SLT
                         IN_1..7 = Ground
```

This produces 0x00 when SLT=0, 0x01 when SLT=1.

---

## Implementation Plan

### Step 1: Create Vcc Component
Simple component that outputs constant HIGH (complement of Ground).

### Step 2: Create Ground8 Component (or inline)
8× Ground outputs joined into 8-bit bus for B inputs of INC/DEC/NEG.

### Step 3: Create Mux16to1 and Mux16to1_8bit
Build from existing Mux8to1 + Mux2to1:
- Two Mux8to1 select within high/low halves
- One Mux2to1 selects between halves using Op[3]

### Step 4: Build ALU8 Core
1. Instantiate all 16 functional units
2. Wire A to all units
3. Wire B to logic and arithmetic units
4. Wire Ground8 to INC/DEC/NEG B inputs
5. Wire Vcc to INC/DEC/NEG Cin inputs
6. Wire Ground to Adder8.Cin

### Step 5: Build Result Mux
- Collect all 16 results
- Route through Mux16to1_8bit
- Op[3:0] controls selection

### Step 6: Build Carry Mux
- Collect carry signals from ADD, SUB, shifts, INC, DEC, NEG
- Route through Mux16to1 (1-bit)
- Ground for operations without carry

### Step 7: Build Overflow Mux
- Collect overflow signals from ADD, SUB, INC, DEC, NEG
- Route through Mux16to1 (1-bit)
- Ground for operations without overflow

### Step 8: Build Flag Logic
- Zero: NOT8(Result) → AND tree, or custom Zero8 component
- Negative: Wire Result[7] directly
- Carry: Output of carry mux
- Overflow: Output of overflow mux

---

## Testing Strategy

### Unit Test: ALU8Test

Test all 16 operations with representative values:

```cpp
// Arithmetic
{Op=ADD, A=0x12, B=0x34} → Result=0x46, Z=0, C=0, V=0, N=0
{Op=ADD, A=0xFF, B=0x01} → Result=0x00, Z=1, C=1, V=0, N=0
{Op=ADD, A=0x7F, B=0x01} → Result=0x80, Z=0, C=0, V=1, N=1
{Op=SUB, A=0x50, B=0x30} → Result=0x20, Z=0, C=1, V=0, N=0
{Op=SUB, A=0x00, B=0x01} → Result=0xFF, Z=0, C=0, V=0, N=1

// Logic
{Op=AND, A=0xF0, B=0x0F} → Result=0x00, Z=1, N=0
{Op=OR,  A=0xF0, B=0x0F} → Result=0xFF, Z=0, N=1
{Op=XOR, A=0xFF, B=0xFF} → Result=0x00, Z=1, N=0
{Op=NOT, A=0x55}         → Result=0xAA, Z=0, N=1

// Shifts
{Op=SLL, A=0x01} → Result=0x02, C=0
{Op=SLL, A=0x80} → Result=0x00, C=1, Z=1
{Op=SRL, A=0x80} → Result=0x40, C=0
{Op=SRA, A=0x80} → Result=0xC0, C=0, N=1
{Op=SRA, A=0xFE} → Result=0xFF, C=0, N=1

// Comparison
{Op=SLT,  A=0xFF, B=0x01} → Result=0x01  // -1 < 1 (signed)
{Op=SLT,  A=0x01, B=0xFF} → Result=0x00  // 1 > -1 (signed)
{Op=SLTU, A=0x01, B=0xFF} → Result=0x01  // 1 < 255 (unsigned)
{Op=SLTU, A=0xFF, B=0x01} → Result=0x00  // 255 > 1 (unsigned)

// Inc/Dec/Neg
{Op=INC, A=0x00} → Result=0x01, C=0
{Op=INC, A=0xFF} → Result=0x00, C=1, Z=1
{Op=DEC, A=0x01} → Result=0x00, Z=1
{Op=DEC, A=0x00} → Result=0xFF, N=1
{Op=NEG, A=0x01} → Result=0xFF  // -1
{Op=NEG, A=0x80} → Result=0x80, V=1  // -(-128) overflows

// NAND/NOR
{Op=NAND, A=0xFF, B=0xFF} → Result=0x00, Z=1
{Op=NOR,  A=0x00, B=0x00} → Result=0xFF, N=1
```

### Edge Cases to Test
- Zero flag: Results of 0x00
- Carry: ADD overflow, SUB borrow, shift-out bits
- Overflow: 0x7F+1, 0x80-1, NEG(0x80)
- Negative: Any result with bit 7 set

---

## Component Summary

### New Components Needed for ALU8

| Component | Description | Complexity |
|-----------|-------------|------------|
| Vcc | Constant HIGH output | Trivial |
| Mux16to1 | 1-bit 16:1 mux | 2× Mux8to1 + Mux2to1 |
| Mux16to1_8bit | 8-bit 16:1 mux | 2× Mux8to1_8bit + Mux2to1_8bit |
| ZeroDetect8 | NOR of 8 bits | NOR8 + inverter logic |
| ALU8 | Top-level integration | All above + wiring |

### Gate Count Estimate

| Section | Gates |
|---------|-------|
| Logic units (6×) | ~48 |
| Arithmetic units (6×) | ~600 |
| Shift units (3×) | ~30 |
| Comparators (2×) | ~200 |
| Result mux (16:1 8-bit) | ~400 |
| Carry/Overflow mux | ~50 |
| Flag logic | ~20 |
| **Total** | **~1350 gates** |

---

## Success Criteria

- [ ] All 16 operations produce correct results
- [ ] All 4 flags computed correctly for each operation
- [ ] Passes comprehensive test suite (50+ test cases)
- [ ] Visualizer can display ALU8 with time-scrubbing
- [ ] Documentation complete

---

**Next Step**: Implement Vcc, Mux16to1, Mux16to1_8bit, then integrate ALU8.
