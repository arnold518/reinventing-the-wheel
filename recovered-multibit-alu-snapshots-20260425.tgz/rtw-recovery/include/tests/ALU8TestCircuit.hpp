#pragma once

#include "components/IOComponent.hpp"

/**
 * @brief Test circuit for ALU8 (8-bit Arithmetic Logic Unit)
 *
 * Wraps the ALU8 component for TruthTableTest verification.
 *
 * Inputs:
 *   A    (Pin<8>) - First operand
 *   B    (Pin<8>) - Second operand
 *   OP   (Pin<4>) - Operation select (4-bit opcode)
 *
 * Outputs:
 *   OUT      (Pin<8>) - Operation result
 *   ZERO     (Pin<1>) - Zero flag
 *   CARRY    (Pin<1>) - Carry/borrow flag
 *   OVERFLOW (Pin<1>) - Signed overflow flag
 *   NEGATIVE (Pin<1>) - Negative flag (sign bit)
 */
class ALU8TestCircuit : public IOComponent {
public:
    ALU8TestCircuit(std::string name);
    static constexpr const char* TypeName = "ALU8TestCircuit";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};
