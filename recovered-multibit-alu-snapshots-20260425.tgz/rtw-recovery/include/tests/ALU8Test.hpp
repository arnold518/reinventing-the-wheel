#pragma once

#include "simulator/TruthTableTest.hpp"

/**
 * @brief Test class for ALU8 (8-bit Arithmetic Logic Unit)
 *
 * Tests all 16 ALU operations with various input combinations:
 *   0x0 ADD  - A + B
 *   0x1 SUB  - A - B
 *   0x2 AND  - A & B
 *   0x3 OR   - A | B
 *   0x4 XOR  - A ^ B
 *   0x5 NOT  - ~A
 *   0x6 SHL  - A << 1
 *   0x7 SHR  - A >> 1 (logical)
 *   0x8 SRA  - A >> 1 (arithmetic)
 *   0x9 INC  - A + 1
 *   0xA DEC  - A - 1
 *   0xB NEG  - -A (two's complement)
 *   0xC PASS_A - Pass through A
 *   0xD PASS_B - Pass through B
 *   0xE CMP  - Compare (flags only)
 *   0xF ZERO - Output zero
 *
 * Also verifies flags: ZERO, CARRY, OVERFLOW, NEGATIVE
 */
class ALU8Test : public TruthTableTest {
public:
    ALU8Test() { time_step_ = 10000; }  // Very long time step for extremely deep circuit

    std::string getTestName() const override;
    void setupCircuit() override;
    std::vector<TruthRow> getTruthTable() const override;
};
