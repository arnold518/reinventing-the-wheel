#pragma once

#include "components/IOComponent.hpp"

/**
 * @file Mux.hpp
 * @brief Multiplexer components for ALU8 implementation
 *
 * Multiplexers are critical infrastructure for selecting ALU operation results.
 * This file provides a hierarchy of multiplexers:
 *
 * 1-bit multiplexers (basic building blocks):
 * - Mux2to1: 2:1 multiplexer using AND-OR logic
 * - Mux4to1: 4:1 multiplexer (cascade of Mux2to1)
 * - Mux8to1: 8:1 multiplexer (tree of Mux2to1)
 *
 * 8-bit multiplexers (parallel arrays):
 * - Mux2to1_8bit: 8 parallel Mux2to1 (1-bit select)
 * - Mux4to1_8bit: 8 parallel Mux4to1 (2-bit select)
 * - Mux8to1_8bit: 8 parallel Mux8to1 (3-bit select)
 */

// ========== 1-BIT MULTIPLEXERS ==========

/**
 * @brief 2:1 Multiplexer (1-bit)
 *
 * Selects between two 1-bit inputs based on select signal.
 * Logic: OUT = (A AND ~SEL) OR (B AND SEL)
 *
 * Inputs:
 *   A (Pin<1>)   - Input 0
 *   B (Pin<1>)   - Input 1
 *   SEL (Pin<1>) - Select (0=A, 1=B)
 * Outputs:
 *   OUT (Pin<1>) - Selected output
 */
class Mux2to1 : public IOComponent
{
public:
    Mux2to1(std::string name);
    static constexpr const char* TypeName = "Mux2to1";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

/**
 * @brief 4:1 Multiplexer (1-bit)
 *
 * Selects one of four 1-bit inputs based on 2-bit select signal.
 * Constructed from 3× Mux2to1 in tree structure.
 *
 * Inputs:
 *   IN0, IN1, IN2, IN3 (Pin<1>) - Four inputs
 *   SEL (Pin<2>) - Select (00=IN0, 01=IN1, 10=IN2, 11=IN3)
 * Outputs:
 *   OUT (Pin<1>) - Selected output
 */
class Mux4to1 : public IOComponent
{
public:
    Mux4to1(std::string name);
    static constexpr const char* TypeName = "Mux4to1";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

/**
 * @brief 8:1 Multiplexer (1-bit)
 *
 * Selects one of eight 1-bit inputs based on 3-bit select signal.
 * Constructed from 7× Mux2to1 in tree structure.
 *
 * Inputs:
 *   IN0-IN7 (Pin<1>) - Eight inputs
 *   SEL (Pin<3>) - Select (000=IN0, ..., 111=IN7)
 * Outputs:
 *   OUT (Pin<1>) - Selected output
 */
class Mux8to1 : public IOComponent
{
public:
    Mux8to1(std::string name);
    static constexpr const char* TypeName = "Mux8to1";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// ========== 8-BIT MULTIPLEXERS ==========

/**
 * @brief 2:1 Multiplexer (8-bit)
 *
 * Selects between two 8-bit buses based on select signal.
 * Constructed from 8× Mux2to1 in parallel.
 *
 * Inputs:
 *   A (Pin<8>)   - Input 0
 *   B (Pin<8>)   - Input 1
 *   SEL (Pin<1>) - Select (0=A, 1=B)
 * Outputs:
 *   OUT (Pin<8>) - Selected 8-bit output
 */
class Mux2to1_8bit : public IOComponent
{
public:
    Mux2to1_8bit(std::string name);
    static constexpr const char* TypeName = "Mux2to1_8bit";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

/**
 * @brief 4:1 Multiplexer (8-bit)
 *
 * Selects one of four 8-bit buses based on 2-bit select signal.
 * Constructed from 8× Mux4to1 in parallel.
 *
 * Inputs:
 *   IN0, IN1, IN2, IN3 (Pin<8>) - Four 8-bit inputs
 *   SEL (Pin<2>) - Select (00=IN0, 01=IN1, 10=IN2, 11=IN3)
 * Outputs:
 *   OUT (Pin<8>) - Selected 8-bit output
 */
class Mux4to1_8bit : public IOComponent
{
public:
    Mux4to1_8bit(std::string name);
    static constexpr const char* TypeName = "Mux4to1_8bit";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

/**
 * @brief 8:1 Multiplexer (8-bit)
 *
 * Selects one of eight 8-bit buses based on 3-bit select signal.
 * Constructed from 8× Mux8to1 in parallel.
 *
 * Inputs:
 *   IN0-IN7 (Pin<8>) - Eight 8-bit inputs
 *   SEL (Pin<3>) - Select (000=IN0, ..., 111=IN7)
 * Outputs:
 *   OUT (Pin<8>) - Selected 8-bit output
 */
class Mux8to1_8bit : public IOComponent
{
public:
    Mux8to1_8bit(std::string name);
    static constexpr const char* TypeName = "Mux8to1_8bit";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// ========== 16-INPUT MULTIPLEXERS ==========

/**
 * @brief 16:1 Multiplexer (1-bit)
 *
 * Selects one of sixteen 1-bit inputs based on 4-bit select signal.
 * Constructed from 2× Mux8to1 + 1× Mux2to1.
 *
 * Inputs:
 *   IN0-IN15 (Pin<1>) - Sixteen inputs
 *   SEL (Pin<4>) - Select (0000=IN0, ..., 1111=IN15)
 * Outputs:
 *   OUT (Pin<1>) - Selected output
 */
class Mux16to1 : public IOComponent
{
public:
    Mux16to1(std::string name);
    static constexpr const char* TypeName = "Mux16to1";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

/**
 * @brief 16:1 Multiplexer (8-bit)
 *
 * Selects one of sixteen 8-bit buses based on 4-bit select signal.
 * Constructed from 2× Mux8to1_8bit + 1× Mux2to1_8bit.
 *
 * Inputs:
 *   IN0-IN15 (Pin<8>) - Sixteen 8-bit inputs
 *   SEL (Pin<4>) - Select (0000=IN0, ..., 1111=IN15)
 * Outputs:
 *   OUT (Pin<8>) - Selected 8-bit output
 */
class Mux16to1_8bit : public IOComponent
{
public:
    Mux16to1_8bit(std::string name);
    static constexpr const char* TypeName = "Mux16to1_8bit";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};
