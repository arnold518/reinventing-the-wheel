#pragma once

#include "components/BasicComponent.hpp"
#include <iostream>

class NOTGate : public BasicComponent
{
public:
    NOTGate(std::string name);
    static constexpr const char* TypeName = "NOTGate";
    const char* getTypeName() const override { return TypeName; }
    void evaluate(size_t current_time, Simulator& simulator) override;
};

class ANDGate : public BasicComponent
{
public:
    ANDGate(std::string name);
    static constexpr const char* TypeName = "ANDGate";
    const char* getTypeName() const override { return TypeName; }
    void evaluate(size_t current_time, Simulator& simulator) override;
};

class NANDGate : public BasicComponent
{
public:
    NANDGate(std::string name);
    static constexpr const char* TypeName = "NANDGate";
    const char* getTypeName() const override { return TypeName; }
    void evaluate(size_t current_time, Simulator& simulator) override;
};

class ORGate : public BasicComponent
{
public:
    ORGate(std::string name);
    static constexpr const char* TypeName = "ORGate";
    const char* getTypeName() const override { return TypeName; }
    void evaluate(size_t current_time, Simulator& simulator) override;
};

class NORGate : public BasicComponent
{
public:
    NORGate(std::string name);
    static constexpr const char* TypeName = "NORGate";
    const char* getTypeName() const override { return TypeName; }
    void evaluate(size_t current_time, Simulator& simulator) override;
};

class XORGate : public BasicComponent
{
public:
    XORGate(std::string name);
    static constexpr const char* TypeName = "XORGate";
    const char* getTypeName() const override { return TypeName; }
    void evaluate(size_t current_time, Simulator& simulator) override;
};

class XNORGate : public BasicComponent
{
public:
    XNORGate(std::string name);
    static constexpr const char* TypeName = "XNORGate";
    const char* getTypeName() const override { return TypeName; }
    void evaluate(size_t current_time, Simulator& simulator) override;
};

// Ground: Always outputs LOW (constant 0)
// Used for tie-low connections in shift operations, etc.
class Ground : public BasicComponent
{
public:
    Ground(std::string name);
    static constexpr const char* TypeName = "Ground";
    const char* getTypeName() const override { return TypeName; }
    void evaluate(size_t current_time, Simulator& simulator) override;
};

// Vcc: Always outputs HIGH (constant 1)
// Used for tie-high connections (e.g., Cin=1 for increment)
class Vcc : public BasicComponent
{
public:
    Vcc(std::string name);
    static constexpr const char* TypeName = "Vcc";
    const char* getTypeName() const override { return TypeName; }
    void evaluate(size_t current_time, Simulator& simulator) override;
};