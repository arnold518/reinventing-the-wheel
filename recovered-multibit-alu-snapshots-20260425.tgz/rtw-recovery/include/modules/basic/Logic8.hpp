#pragma once

#include "components/IOComponent.hpp"

/**
 * 8-Bit Logical Operations
 *
 * These components perform bitwise logical operations on 8-bit values.
 * Each operation is executed in parallel across all 8 bits.
 *
 * Common interface for all:
 * - Inputs: A (Pin<8>), B (Pin<8>) [NOT8 only uses A]
 * - Output: OUT (Pin<8>)
 *
 * Implementation: Uses 8 parallel single-bit gates with BitSplitter/BitJoiner
 * for educational visualization. Users can see the 8 individual gate operations.
 */

// ========== AND8 ==========
/**
 * 8-bit Bitwise AND
 * OUT[i] = A[i] AND B[i] for i = 0..7
 * Internal: 8× ANDGate with BitSplitter/BitJoiner
 */
class AND8 : public IOComponent
{
public:
    AND8(std::string name);
    static constexpr const char* TypeName = "AND8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// ========== OR8 ==========
/**
 * 8-bit Bitwise OR
 * OUT[i] = A[i] OR B[i] for i = 0..7
 * Internal: 8× ORGate with BitSplitter/BitJoiner
 */
class OR8 : public IOComponent
{
public:
    OR8(std::string name);
    static constexpr const char* TypeName = "OR8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// ========== XOR8 ==========
/**
 * 8-bit Bitwise XOR
 * OUT[i] = A[i] XOR B[i] for i = 0..7
 * Internal: 8× XORGate with BitSplitter/BitJoiner
 */
class XOR8 : public IOComponent
{
public:
    XOR8(std::string name);
    static constexpr const char* TypeName = "XOR8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// ========== NOT8 ==========
/**
 * 8-bit Bitwise NOT (Invert)
 * OUT[i] = NOT A[i] for i = 0..7
 * Note: Only uses input A
 * Internal: 8× NOTGate with BitSplitter/BitJoiner
 */
class NOT8 : public IOComponent
{
public:
    NOT8(std::string name);
    static constexpr const char* TypeName = "NOT8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// ========== NAND8 ==========
/**
 * 8-bit Bitwise NAND
 * OUT[i] = NOT (A[i] AND B[i]) for i = 0..7
 * Internal: 8× NANDGate with BitSplitter/BitJoiner
 */
class NAND8 : public IOComponent
{
public:
    NAND8(std::string name);
    static constexpr const char* TypeName = "NAND8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// ========== NOR8 ==========
/**
 * 8-bit Bitwise NOR
 * OUT[i] = NOT (A[i] OR B[i]) for i = 0..7
 * Internal: 8× NORGate with BitSplitter/BitJoiner
 */
class NOR8 : public IOComponent
{
public:
    NOR8(std::string name);
    static constexpr const char* TypeName = "NOR8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};
