#pragma once

#include "components/IOComponent.hpp"
#include "components/ComponentBuilder.hpp"

/**
 * @brief 8-bit Ripple-Carry Adder with native multi-bit pins
 *
 * Demonstrates Phase 4 native multi-bit pin functionality.
 * Uses Pin<8> for data inputs/outputs instead of 8 separate Pin<1> instances.
 *
 * Interface:
 * - Inputs: A (Pin<8>), B (Pin<8>), Cin (Pin<1>)
 * - Outputs: Sum (Pin<8>), Cout (Pin<1>)
 *
 * Implementation: Internally uses 8 FullAdder components in ripple-carry chain,
 * with Rewire components to convert between Pin<8> and individual bits.
 */
class Adder8 : public IOComponent
{
public:
    Adder8(std::string name);
    void buildInternals(ComponentBuilder& builder) override;
};
