#pragma once

#include "components/IOComponent.hpp"
#include "components/ComponentBuilder.hpp"

/**
 * @brief 8-bit Two's Complement (Negation)
 *
 * Computes the two's complement of input A: -A = ~A + 1
 *
 * Interface:
 * - Input: A (Pin<8>)
 * - Outputs: Result (Pin<8>), Cout (Pin<1>), Overflow (Pin<1>)
 *
 * Implementation: NOT8 + Adder8 with B=0, Cin=1
 * Overflow: Set when input is 0x80 (-128), as -(-128) cannot be represented in 8-bit signed
 */
class TwosComplement8 : public IOComponent
{
public:
    TwosComplement8(std::string name);
    void buildInternals(ComponentBuilder& builder) override;
};

/**
 * @brief 8-bit Subtractor (A - B)
 *
 * Subtracts B from A using two's complement addition: A - B = A + (~B + 1)
 *
 * Interface:
 * - Inputs: A (Pin<8>), B (Pin<8>)
 * - Outputs: Result (Pin<8>), Cout (Pin<1>), Overflow (Pin<1>)
 *
 * Implementation: Adder8 with B_inverted = ~B, Cin=1
 * Cout: Borrow flag (inverted carry - Cout=0 means borrow occurred)
 * Overflow: Signed overflow detection
 */
class Subtractor8 : public IOComponent
{
public:
    Subtractor8(std::string name);
    void buildInternals(ComponentBuilder& builder) override;
};

/**
 * @brief 8-bit Subtractor with Borrow (A - B - Borrow)
 *
 * Subtracts B and borrow from A: A - B - Borrow
 * Used for multi-byte subtraction chains
 *
 * Interface:
 * - Inputs: A (Pin<8>), B (Pin<8>), Bin (Pin<1>) - Borrow input
 * - Outputs: Result (Pin<8>), Bout (Pin<1>), Overflow (Pin<1>)
 *
 * Implementation: A - B - Bin = A + ~B + (1 - Bin) = A + ~B + ~Bin
 * Bout: Borrow output (Bout=1 means no borrow, Bout=0 means borrow occurred)
 */
class SubtractorWithBorrow8 : public IOComponent
{
public:
    SubtractorWithBorrow8(std::string name);
    void buildInternals(ComponentBuilder& builder) override;
};

/**
 * @brief 8-bit Incrementer (A + 1)
 *
 * Increments input A by 1
 *
 * Interface:
 * - Input: A (Pin<8>)
 * - Outputs: Result (Pin<8>), Cout (Pin<1>), Overflow (Pin<1>)
 *
 * Implementation: Adder8 with B=0, Cin=1
 * Cout: Set when A = 0xFF (wraparound)
 * Overflow: Set when A = 0x7F (127 + 1 = -128 in signed)
 */
class Incrementer8 : public IOComponent
{
public:
    Incrementer8(std::string name);
    void buildInternals(ComponentBuilder& builder) override;
};

/**
 * @brief 8-bit Decrementer (A - 1)
 *
 * Decrements input A by 1
 *
 * Interface:
 * - Input: A (Pin<8>)
 * - Outputs: Result (Pin<8>), Bout (Pin<1>), Overflow (Pin<1>)
 *
 * Implementation: Subtractor8 with B=1 or Adder8 with B=0xFF, Cin=0
 * Bout: Set when A = 0x00 (underflow/borrow)
 * Overflow: Set when A = 0x80 (-128 - 1 = 127 in signed)
 */
class Decrementer8 : public IOComponent
{
public:
    Decrementer8(std::string name);
    void buildInternals(ComponentBuilder& builder) override;
};
