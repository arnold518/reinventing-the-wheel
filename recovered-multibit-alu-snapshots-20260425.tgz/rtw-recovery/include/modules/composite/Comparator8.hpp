#pragma once

#include "components/IOComponent.hpp"

// EqualityChecker8: Checks if two 8-bit values are equal
// Uses 8× XNOR gates + AND tree
// Inputs: A<8>, B<8>
// Outputs: EQ (HIGH if A == B)
class EqualityChecker8 : public IOComponent
{
public:
    EqualityChecker8(std::string name);
    static constexpr const char* TypeName = "EqualityChecker8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// Comparator8: Unsigned 8-bit magnitude comparator
// Compares two unsigned 8-bit values
// Inputs: A<8>, B<8>
// Outputs: LT (A < B), GT (A > B), EQ (A == B)
class Comparator8 : public IOComponent
{
public:
    Comparator8(std::string name);
    static constexpr const char* TypeName = "Comparator8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// SignedComparator8: Signed 8-bit comparator (two's complement)
// Compares two signed 8-bit values
// Inputs: A<8>, B<8>
// Outputs: SLT (A < B signed), SGT (A > B signed), SEQ (A == B)
class SignedComparator8 : public IOComponent
{
public:
    SignedComparator8(std::string name);
    static constexpr const char* TypeName = "SignedComparator8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};
