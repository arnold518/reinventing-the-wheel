#pragma once

#include "components/IOComponent.hpp"

/**
 * @brief 8-bit Arithmetic Logic Unit
 *
 * A complete ALU supporting 16 operations selected by a 4-bit opcode.
 * All operations compute in parallel; the result mux selects the output.
 *
 * Opcodes:
 *   0x0 ADD  - A + B (with carry)
 *   0x1 SUB  - A - B (with borrow)
 *   0x2 AND  - A & B (bitwise)
 *   0x3 OR   - A | B (bitwise)
 *   0x4 XOR  - A ^ B (bitwise)
 *   0x5 NOT  - ~A (bitwise invert)
 *   0x6 SHL  - A << 1 (shift left logical)
 *   0x7 SHR  - A >> 1 (shift right logical)
 *   0x8 SRA  - A >> 1 (shift right arithmetic)
 *   0x9 INC  - A + 1 (increment)
 *   0xA DEC  - A - 1 (decrement)
 *   0xB NEG  - -A (two's complement negation)
 *   0xC PASS_A - Pass through A unchanged
 *   0xD PASS_B - Pass through B unchanged
 *   0xE CMP  - Compare A and B (result = A - B for flags)
 *   0xF ZERO - Output zero constant
 *
 * Inputs:
 *   A    (Pin<8>) - First operand
 *   B    (Pin<8>) - Second operand
 *   OP   (Pin<4>) - Operation select (4-bit opcode)
 *
 * Outputs:
 *   OUT      (Pin<8>) - Operation result
 *   ZERO     (Pin<1>) - Zero flag: HIGH when result == 0
 *   CARRY    (Pin<1>) - Carry/borrow flag from arithmetic operations
 *   OVERFLOW (Pin<1>) - Signed overflow flag
 *   NEGATIVE (Pin<1>) - Negative flag: result[7] (sign bit)
 *
 * Internal structure:
 *   - All operation units compute simultaneously
 *   - Mux16to1_8bit selects result based on OP
 *   - Mux16to1 (1-bit) selects appropriate carry and overflow
 *   - ZeroDetect8 generates zero flag
 *   - Result bit 7 becomes negative flag
 */
class ALU8 : public IOComponent
{
public:
    ALU8(std::string name);
    static constexpr const char* TypeName = "ALU8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};
