#pragma once

#include "components/IOComponent.hpp"

/**
 * @brief 8-bit Zero Detector
 *
 * Outputs HIGH when all 8 input bits are LOW (i.e., input == 0x00).
 * Implemented as a tree of OR gates followed by a NOR gate.
 *
 * Logic: ZERO = NOT(A[0] OR A[1] OR ... OR A[7])
 *             = 1 when A == 0x00
 *             = 0 otherwise
 *
 * Inputs:
 *   A (Pin<8>) - 8-bit input to test for zero
 * Outputs:
 *   ZERO (Pin<1>) - HIGH if A == 0x00, LOW otherwise
 */
class ZeroDetect8 : public IOComponent
{
public:
    ZeroDetect8(std::string name);
    static constexpr const char* TypeName = "ZeroDetect8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};
