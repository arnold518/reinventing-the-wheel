#pragma once

#include "components/IOComponent.hpp"

// ShiftLeftLogical8: Shift left by 1 bit, fill LSB with 0
// Input: A<8>
// Output: Result<8> (A << 1), Carry (A[7])
class ShiftLeftLogical8 : public IOComponent
{
public:
    ShiftLeftLogical8(std::string name);
    static constexpr const char* TypeName = "ShiftLeftLogical8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// ShiftRightLogical8: Shift right by 1 bit, fill MSB with 0
// Input: A<8>
// Output: Result<8> (A >> 1), Carry (A[0])
class ShiftRightLogical8 : public IOComponent
{
public:
    ShiftRightLogical8(std::string name);
    static constexpr const char* TypeName = "ShiftRightLogical8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};

// ShiftRightArithmetic8: Shift right by 1 bit, preserve sign (fill MSB with A[7])
// Input: A<8>
// Output: Result<8> (A >> 1 arithmetic), Carry (A[0])
class ShiftRightArithmetic8 : public IOComponent
{
public:
    ShiftRightArithmetic8(std::string name);
    static constexpr const char* TypeName = "ShiftRightArithmetic8";
    const char* getTypeName() const override { return TypeName; }
    void buildInternals(ComponentBuilder& builder) override;
};
