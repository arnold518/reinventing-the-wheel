#pragma once

#include "components/IOComponent.hpp"
#include "components/BasicComponent.hpp"

/**
 * BitSplitter - Converts a multi-bit wire into individual single-bit wires
 *
 * Template parameter WIDTH specifies the number of bits.
 * Has one Pin<WIDTH> input and WIDTH Pin<1> outputs.
 *
 * Example: BitSplitter<8> takes Pin<8> input and produces 8 Pin<1> outputs
 */
template<size_t WIDTH>
class BitSplitter : public BasicComponent {
public:
    explicit BitSplitter(std::string name);
    void evaluate(size_t time, Simulator& sim) override;
};

/**
 * BitJoiner - Converts individual single-bit wires into a multi-bit wire
 *
 * Template parameter WIDTH specifies the number of bits.
 * Has WIDTH Pin<1> inputs and one Pin<WIDTH> output.
 *
 * Example: BitJoiner<8> takes 8 Pin<1> inputs and produces Pin<8> output
 */
template<size_t WIDTH>
class BitJoiner : public BasicComponent {
public:
    explicit BitJoiner(std::string name);
    void evaluate(size_t time, Simulator& sim) override;
};
