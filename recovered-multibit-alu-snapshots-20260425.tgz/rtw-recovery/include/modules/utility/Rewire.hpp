#pragma once

#include "components/BasicComponent.hpp"
#include <vector>
#include <string>
#include <map>
#include <set>

/**
 * Rewire Component - Flexible Bit-Level Routing (Phase 6: Pin<WIDTH> Native)
 *
 * Provides arbitrary bit-level routing between wires of different widths.
 * Now uses Pin<WIDTH> native interface instead of bracket notation.
 *
 * Phase 6 Update: Changed from IOComponent to BasicComponent
 * - Uses addPinDynamic() to create Pin<WIDTH> at runtime
 * - Implements evaluate() for direct bit manipulation via PinBase interface
 * - No longer creates Pin<1> with bracket notation
 *
 * Uses a relaxed model that allows:
 * - Different total input/output bit counts
 * - Unmapped output bits (use configurable default value)
 * - Unmapped input bits (ignored, dangling OK)
 * - One input bit mapped to multiple output bits (e.g., sign extension)
 *
 * Use cases:
 * - Bit extraction: Wire<32> → Wire<8> (extract low byte)
 * - Zero extension: Wire<8> → Wire<32> (upper bits = 0)
 * - Sign extension: Wire<8> → Wire<32> (replicate sign bit)
 * - Bit packing/unpacking: Pin<8> ↔ 8×Pin<1>
 * - Bit reversal, shuffling, arbitrary permutations
 */
class Rewire : public BasicComponent {
public:
    /**
     * Default value for unmapped output bits
     */
    enum class UnmappedBitValue {
        UNKNOWN,  // Default: unconnected bits output UNKNOWN state
        LOW,      // Zero-extension: unconnected bits output 0
        HIGH      // One-extension: unconnected bits output 1
    };

    /**
     * Specification for a single wire (input or output)
     */
    struct WireSpec {
        std::string name;
        size_t width;

        WireSpec(std::string n, size_t w = 1)
            : name(std::move(n)), width(w) {}
    };

    /**
     * Single bit mapping: source[bit] → destination[bit]
     */
    struct BitMap {
        std::string src_wire;   // Source wire name
        size_t src_bit;         // Bit index in source
        std::string dst_wire;   // Destination wire name
        size_t dst_bit;         // Bit index in destination

        BitMap(std::string sw, size_t sb, std::string dw, size_t db)
            : src_wire(std::move(sw)), src_bit(sb),
              dst_wire(std::move(dw)), dst_bit(db) {}
    };

private:
    std::vector<WireSpec> inputs;
    std::vector<WireSpec> outputs;
    std::vector<BitMap> bit_mappings;
    UnmappedBitValue unmapped_default;

    // Track which output bits are mapped (for unmapped bit handling)
    std::set<std::pair<std::string, size_t>> mapped_output_bits;

public:
    /**
     * Constructor (Phase 6: Creates Pin<WIDTH> via addPinDynamic)
     *
     * @param name Component name
     * @param input_specs Vector of input wire specifications
     * @param output_specs Vector of output wire specifications
     * @param mappings Vector of bit mappings (source → destination)
     * @param unmapped Default value for unmapped output bits
     */
    Rewire(std::string name,
           std::vector<WireSpec> input_specs,
           std::vector<WireSpec> output_specs,
           std::vector<BitMap> mappings,
           UnmappedBitValue unmapped = UnmappedBitValue::UNKNOWN);

    /**
     * Validation
     *
     * Checks:
     * - All mapped wires exist in input/output specs
     * - All bit indices are in valid range
     * - Warns about unmapped output bits
     *
     * @return true if mappings are valid, false otherwise
     */
    bool validateMappings() const;

    /**
     * Calculate total input bits across all input wires
     */
    size_t getTotalInputBits() const;

    /**
     * Calculate total output bits across all output wires
     */
    size_t getTotalOutputBits() const;

    /**
     * Evaluate - Phase 6: Direct bit routing via PinBase interface
     *
     * Reads input bits, routes according to bit_mappings, writes output bits.
     * BasicComponent's evaluate() is called by the simulator when input changes.
     */
    void evaluate(size_t time, Simulator& sim) override;

private:
    /**
     * Helper: Find wire spec by name in a vector
     */
    const WireSpec* findWireSpec(const std::vector<WireSpec>& specs, const std::string& name) const;

    /**
     * Helper: Convert UnmappedBitValue enum to LogicValue
     */
    LogicValue getUnmappedValue() const;

    /**
     * Helper: Check if a specific output bit is mapped
     */
    bool isBitMapped(const std::string& wire_name, size_t bit_index) const;
};

// ===================================================================
// Helper Functions for Creating Bit Mappings
// ===================================================================

/**
 * Generate identity mapping: src[offset..offset+count-1] → dst[dst_offset..dst_offset+count-1]
 *
 * Example: identity_mapping("A", 0, 8, "B", 0) creates:
 *   A[0]→B[0], A[1]→B[1], ..., A[7]→B[7]
 */
std::vector<Rewire::BitMap> identity_mapping(
    const std::string& src_wire,
    size_t src_offset,
    size_t count,
    const std::string& dst_wire,
    size_t dst_offset = 0);

/**
 * Generate unpacking mapping: single multi-bit wire → multiple single-bit wires
 *
 * Example: unpack_mapping("BUS", 8, {"B0", "B1", ..., "B7"}) creates:
 *   BUS[0]→B0[0], BUS[1]→B1[0], ..., BUS[7]→B7[0]
 */
std::vector<Rewire::BitMap> unpack_mapping(
    const std::string& src_bus,
    size_t width,
    const std::vector<std::string>& dst_wires);

/**
 * Generate packing mapping: multiple single-bit wires → single multi-bit wire
 *
 * Example: pack_mapping({"B0", "B1", ..., "B7"}, "BUS") creates:
 *   B0[0]→BUS[0], B1[0]→BUS[1], ..., B7[0]→BUS[7]
 */
std::vector<Rewire::BitMap> pack_mapping(
    const std::vector<std::string>& src_wires,
    const std::string& dst_bus);

/**
 * Generate slice mapping: src[start..start+length-1] → dst[0..length-1]
 *
 * Example: slice_mapping("DATA", 8, 8, "BYTE1") creates:
 *   DATA[8]→BYTE1[0], DATA[9]→BYTE1[1], ..., DATA[15]→BYTE1[7]
 */
std::vector<Rewire::BitMap> slice_mapping(
    const std::string& src_wire,
    size_t start_bit,
    size_t length,
    const std::string& dst_wire);

/**
 * Generate sign extension mapping: replicate MSB to upper bits
 *
 * Example: sign_extend_mapping("BYTE", 8, "WORD", 32) creates:
 *   BYTE[0]→WORD[0], ..., BYTE[7]→WORD[7],
 *   BYTE[7]→WORD[8], BYTE[7]→WORD[9], ..., BYTE[7]→WORD[31]
 */
std::vector<Rewire::BitMap> sign_extend_mapping(
    const std::string& src_wire,
    size_t src_width,
    const std::string& dst_wire,
    size_t dst_width);
