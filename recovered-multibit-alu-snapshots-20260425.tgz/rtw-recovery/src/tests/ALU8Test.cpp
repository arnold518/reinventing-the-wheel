#include "tests/ALU8Test.hpp"
#include "tests/ALU8TestCircuit.hpp"
#include "components/Component.hpp"
#include "components/ComponentBuilder.hpp"

std::string ALU8Test::getTestName() const {
    return "ALU8Test (8-bit Arithmetic Logic Unit)";
}

void ALU8Test::setupCircuit() {
    root = Component::create<ALU8TestCircuit>("ALU8_TEST_ROOT");
    builder = std::make_unique<ComponentBuilder>(root);
    buildCircuit();
    setInitialState();
}

std::vector<TruthRow> ALU8Test::getTruthTable() const {
    std::vector<TruthRow> rows;

    // Helper to create a test row
    auto makeRow = [](uint8_t a, uint8_t b, uint8_t op, uint8_t expected_out,
                      int zero, int carry, int overflow, int negative) {
        return TruthRow(
            std::map<std::string, PinValue>{
                {"A", PinValue(static_cast<uint64_t>(a))},
                {"B", PinValue(static_cast<uint64_t>(b))},
                {"OP", PinValue(static_cast<uint64_t>(op))}
            },
            std::map<std::string, PinValue>{
                {"OUT", PinValue(static_cast<uint64_t>(expected_out))},
                {"ZERO", PinValue(static_cast<LogicValue>(zero))},
                {"NEGATIVE", PinValue(static_cast<LogicValue>(negative))}
                // Note: CARRY and OVERFLOW vary by operation and are harder to test uniformly
            }
        );
    };

    // ========== OP 0x0: ADD ==========
    rows.push_back(makeRow(0x00, 0x00, 0x0, 0x00, 1, 0, 0, 0));  // 0 + 0 = 0, ZERO=1
    rows.push_back(makeRow(0x01, 0x02, 0x0, 0x03, 0, 0, 0, 0));  // 1 + 2 = 3
    rows.push_back(makeRow(0x7F, 0x01, 0x0, 0x80, 0, 0, 0, 1));  // 127 + 1 = 128 (overflow, negative)
    rows.push_back(makeRow(0xFF, 0x01, 0x0, 0x00, 1, 0, 0, 0));  // 255 + 1 = 0 (wrap, carry)

    // ========== OP 0x1: SUB ==========
    rows.push_back(makeRow(0x05, 0x03, 0x1, 0x02, 0, 0, 0, 0));  // 5 - 3 = 2
    rows.push_back(makeRow(0x03, 0x03, 0x1, 0x00, 1, 0, 0, 0));  // 3 - 3 = 0, ZERO=1
    rows.push_back(makeRow(0x00, 0x01, 0x1, 0xFF, 0, 0, 0, 1));  // 0 - 1 = -1 (255), negative

    // ========== OP 0x2: AND ==========
    rows.push_back(makeRow(0xFF, 0x0F, 0x2, 0x0F, 0, 0, 0, 0));  // 0xFF & 0x0F = 0x0F
    rows.push_back(makeRow(0xAA, 0x55, 0x2, 0x00, 1, 0, 0, 0));  // 0xAA & 0x55 = 0x00, ZERO=1

    // ========== OP 0x3: OR ==========
    rows.push_back(makeRow(0xF0, 0x0F, 0x3, 0xFF, 0, 0, 0, 1));  // 0xF0 | 0x0F = 0xFF, negative
    rows.push_back(makeRow(0x00, 0x00, 0x3, 0x00, 1, 0, 0, 0));  // 0x00 | 0x00 = 0x00, ZERO=1

    // ========== OP 0x4: XOR ==========
    rows.push_back(makeRow(0xFF, 0xFF, 0x4, 0x00, 1, 0, 0, 0));  // 0xFF ^ 0xFF = 0x00, ZERO=1
    rows.push_back(makeRow(0xAA, 0x55, 0x4, 0xFF, 0, 0, 0, 1));  // 0xAA ^ 0x55 = 0xFF, negative

    // ========== OP 0x5: NOT ==========
    rows.push_back(makeRow(0xFF, 0x00, 0x5, 0x00, 1, 0, 0, 0));  // ~0xFF = 0x00, ZERO=1
    rows.push_back(makeRow(0x00, 0x00, 0x5, 0xFF, 0, 0, 0, 1));  // ~0x00 = 0xFF, negative

    // ========== OP 0x6: SHL ==========
    rows.push_back(makeRow(0x01, 0x00, 0x6, 0x02, 0, 0, 0, 0));  // 1 << 1 = 2
    rows.push_back(makeRow(0x80, 0x00, 0x6, 0x00, 1, 0, 0, 0));  // 0x80 << 1 = 0x00 (carry out)

    // ========== OP 0x7: SHR (logical) ==========
    rows.push_back(makeRow(0x80, 0x00, 0x7, 0x40, 0, 0, 0, 0));  // 0x80 >> 1 = 0x40
    rows.push_back(makeRow(0x01, 0x00, 0x7, 0x00, 1, 0, 0, 0));  // 1 >> 1 = 0, ZERO=1

    // ========== OP 0x8: SRA (arithmetic) ==========
    rows.push_back(makeRow(0x80, 0x00, 0x8, 0xC0, 0, 0, 0, 1));  // 0x80 >> 1 = 0xC0 (sign extended)
    rows.push_back(makeRow(0x02, 0x00, 0x8, 0x01, 0, 0, 0, 0));  // 2 >> 1 = 1

    // ========== OP 0x9: INC ==========
    rows.push_back(makeRow(0x00, 0x00, 0x9, 0x01, 0, 0, 0, 0));  // 0 + 1 = 1
    rows.push_back(makeRow(0xFF, 0x00, 0x9, 0x00, 1, 0, 0, 0));  // 255 + 1 = 0 (wrap)

    // ========== OP 0xA: DEC ==========
    rows.push_back(makeRow(0x01, 0x00, 0xA, 0x00, 1, 0, 0, 0));  // 1 - 1 = 0, ZERO=1
    rows.push_back(makeRow(0x00, 0x00, 0xA, 0xFF, 0, 0, 0, 1));  // 0 - 1 = 255 (wrap), negative

    // ========== OP 0xB: NEG ==========
    rows.push_back(makeRow(0x01, 0x00, 0xB, 0xFF, 0, 0, 0, 1));  // -1 = 0xFF, negative
    rows.push_back(makeRow(0x00, 0x00, 0xB, 0x00, 1, 0, 0, 0));  // -0 = 0, ZERO=1

    // ========== OP 0xC: PASS_A ==========
    rows.push_back(makeRow(0x42, 0xFF, 0xC, 0x42, 0, 0, 0, 0));  // Pass A through
    rows.push_back(makeRow(0x00, 0xFF, 0xC, 0x00, 1, 0, 0, 0));  // Pass 0, ZERO=1

    // ========== OP 0xD: PASS_B ==========
    rows.push_back(makeRow(0xFF, 0x42, 0xD, 0x42, 0, 0, 0, 0));  // Pass B through
    rows.push_back(makeRow(0xFF, 0x00, 0xD, 0x00, 1, 0, 0, 0));  // Pass 0, ZERO=1

    // ========== OP 0xF: ZERO ==========
    rows.push_back(makeRow(0xFF, 0xFF, 0xF, 0x00, 1, 0, 0, 0));  // Output 0, ZERO=1

    return rows;
}
