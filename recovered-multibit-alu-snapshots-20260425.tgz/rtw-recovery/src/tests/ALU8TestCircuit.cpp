#include "tests/ALU8TestCircuit.hpp"
#include "modules/composite/ALU8.hpp"
#include "components/ComponentBuilder.hpp"
#include "components/ComponentBuilder.tpp"
#include "components/IOComponent.tpp"
#include "TemplateImplementations.hpp"

ALU8TestCircuit::ALU8TestCircuit(std::string name)
    : IOComponent(std::move(name),
      [](IOComponent* self) {
          // Inputs
          self->addPin<8>("A", PinType::INPUT);
          self->addPin<8>("B", PinType::INPUT);
          self->addPin<4>("OP", PinType::INPUT);
          // Outputs
          self->addPin<8>("OUT", PinType::OUTPUT);
          self->addPin("ZERO", PinType::OUTPUT);
          self->addPin("CARRY", PinType::OUTPUT);
          self->addPin("OVERFLOW", PinType::OUTPUT);
          self->addPin("NEGATIVE", PinType::OUTPUT);
      })
{}

void ALU8TestCircuit::buildInternals(ComponentBuilder& builder) {
    // Create the ALU8
    builder.addNewComponent<ALU8>("ALU");

    // Wire inputs
    builder.addNewWire<8>("a_to_alu",
        builder.getInputPin<8>("A"),
        {builder.getInputPin<ALU8, 8>("ALU", "A")});

    builder.addNewWire<8>("b_to_alu",
        builder.getInputPin<8>("B"),
        {builder.getInputPin<ALU8, 8>("ALU", "B")});

    builder.addNewWire<4>("op_to_alu",
        builder.getInputPin<4>("OP"),
        {builder.getInputPin<ALU8, 4>("ALU", "OP")});

    // Wire outputs
    builder.addNewWire<8>("alu_to_out",
        builder.getOutputPin<ALU8, 8>("ALU", "OUT"),
        {builder.getOutputPin<8>("OUT")});

    builder.addNewWire("alu_to_zero",
        builder.getOutputPin<ALU8>("ALU", "ZERO"),
        {builder.getOutputPin("ZERO")});

    builder.addNewWire("alu_to_carry",
        builder.getOutputPin<ALU8>("ALU", "CARRY"),
        {builder.getOutputPin("CARRY")});

    builder.addNewWire("alu_to_overflow",
        builder.getOutputPin<ALU8>("ALU", "OVERFLOW"),
        {builder.getOutputPin("OVERFLOW")});

    builder.addNewWire("alu_to_negative",
        builder.getOutputPin<ALU8>("ALU", "NEGATIVE"),
        {builder.getOutputPin("NEGATIVE")});
}
