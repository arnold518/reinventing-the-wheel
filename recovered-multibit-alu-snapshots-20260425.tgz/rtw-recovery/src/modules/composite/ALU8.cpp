#include "modules/composite/ALU8.hpp"
#include "modules/composite/Adder8.hpp"
#include "modules/composite/Arithmetic8.hpp"
#include "modules/composite/Shifter8.hpp"
#include "modules/composite/ZeroDetect8.hpp"
#include "modules/basic/Logic8.hpp"
#include "modules/basic/Gate.hpp"
#include "modules/basic/Mux.hpp"
#include "modules/utility/BitAdapter.hpp"
#include "modules/utility/BitAdapter.tpp"
#include "components/ComponentBuilder.hpp"
#include "components/ComponentBuilder.tpp"
#include "components/IOComponent.tpp"
#include "TemplateImplementations.hpp"

ALU8::ALU8(std::string name)
    : IOComponent(std::move(name),
      [](IOComponent* self) {
          // Inputs
          self->addPin<8>("A", PinType::INPUT);
          self->addPin<8>("B", PinType::INPUT);
          self->addPin<4>("OP", PinType::INPUT);
          // Outputs
          self->addPin<8>("OUT", PinType::OUTPUT);
          self->addPin("ZERO", PinType::OUTPUT);
          self->addPin("CARRY", PinType::OUTPUT);
          self->addPin("OVERFLOW", PinType::OUTPUT);
          self->addPin("NEGATIVE", PinType::OUTPUT);
      })
{}

void ALU8::buildInternals(ComponentBuilder& builder) {
    // ========== Constant Sources ==========
    // Ground (LOW) and Vcc (HIGH) for operations that need constants
    // Create multiple Ground and Vcc instances to avoid fan-out issues
    // Each pin can only have one external_wire, so we need separate instances
    builder.addNewComponent<Ground>("GND_CONST_ZERO");      // For CONST_ZERO joiner (MUX inputs)
    builder.addNewComponent<Ground>("GND_CONST_ZERO_INC");  // For CONST_ZERO_INC joiner (INC B)
    builder.addNewComponent<Ground>("GND_CONST_ZERO_NEG");  // For CONST_ZERO_NEG joiner (NEG B)
    builder.addNewComponent<Ground>("GND_ADD_CIN");         // For ADD Cin
    builder.addNewComponent<Ground>("GND_DEC_CIN");         // For DEC Cin
    builder.addNewComponent<Ground>("GND_CARRY_MUX");       // For CARRY_MUX unused inputs
    builder.addNewComponent<Ground>("GND_OVERFLOW_MUX");    // For OVERFLOW_MUX unused inputs
    builder.addNewComponent<Vcc>("VCC_CONST_FF");           // For CONST_FF joiner
    builder.addNewComponent<Vcc>("VCC_SUB_CIN");            // For SUB Cin
    builder.addNewComponent<Vcc>("VCC_INC_CIN");            // For INC Cin
    builder.addNewComponent<Vcc>("VCC_NEG_CIN");            // For NEG Cin

    // Create 8-bit constant 0x00 for MUX inputs (IN14, IN15)
    builder.addNewComponent<BitJoiner<8>>("CONST_ZERO");
    builder.addNewWire("gnd_to_zero_all",
        builder.getOutputPin<Ground>("GND_CONST_ZERO", "OUT"),
        {builder.getInputPin<BitJoiner<8>>("CONST_ZERO", "IN_0"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO", "IN_1"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO", "IN_2"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO", "IN_3"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO", "IN_4"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO", "IN_5"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO", "IN_6"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO", "IN_7")});

    // Create 8-bit constant 0x00 for INC B input
    builder.addNewComponent<BitJoiner<8>>("CONST_ZERO_INC");
    builder.addNewWire("gnd_to_zero_inc",
        builder.getOutputPin<Ground>("GND_CONST_ZERO_INC", "OUT"),
        {builder.getInputPin<BitJoiner<8>>("CONST_ZERO_INC", "IN_0"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_INC", "IN_1"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_INC", "IN_2"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_INC", "IN_3"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_INC", "IN_4"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_INC", "IN_5"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_INC", "IN_6"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_INC", "IN_7")});

    // Create 8-bit constant 0x00 for NEG B input
    builder.addNewComponent<BitJoiner<8>>("CONST_ZERO_NEG");
    builder.addNewWire("gnd_to_zero_neg",
        builder.getOutputPin<Ground>("GND_CONST_ZERO_NEG", "OUT"),
        {builder.getInputPin<BitJoiner<8>>("CONST_ZERO_NEG", "IN_0"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_NEG", "IN_1"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_NEG", "IN_2"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_NEG", "IN_3"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_NEG", "IN_4"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_NEG", "IN_5"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_NEG", "IN_6"),
         builder.getInputPin<BitJoiner<8>>("CONST_ZERO_NEG", "IN_7")});

    // Create 8-bit constant 0xFF using a single Vcc with one wire to all joiner inputs
    builder.addNewComponent<BitJoiner<8>>("CONST_FF");
    builder.addNewWire("vcc_to_ff_all",
        builder.getOutputPin<Vcc>("VCC_CONST_FF", "OUT"),
        {builder.getInputPin<BitJoiner<8>>("CONST_FF", "IN_0"),
         builder.getInputPin<BitJoiner<8>>("CONST_FF", "IN_1"),
         builder.getInputPin<BitJoiner<8>>("CONST_FF", "IN_2"),
         builder.getInputPin<BitJoiner<8>>("CONST_FF", "IN_3"),
         builder.getInputPin<BitJoiner<8>>("CONST_FF", "IN_4"),
         builder.getInputPin<BitJoiner<8>>("CONST_FF", "IN_5"),
         builder.getInputPin<BitJoiner<8>>("CONST_FF", "IN_6"),
         builder.getInputPin<BitJoiner<8>>("CONST_FF", "IN_7")});

    // ========== Operation Units ==========
    // 0x0 ADD: A + B
    builder.addNewComponent<Adder8>("OP_ADD");

    // 0x1 SUB: A - B (uses Cin=1)
    builder.addNewComponent<Subtractor8>("OP_SUB");

    // 0x2 AND: A & B
    builder.addNewComponent<AND8>("OP_AND");

    // 0x3 OR: A | B
    builder.addNewComponent<OR8>("OP_OR");

    // 0x4 XOR: A ^ B
    builder.addNewComponent<XOR8>("OP_XOR");

    // 0x5 NOT: ~A
    builder.addNewComponent<NOT8>("OP_NOT");

    // 0x6 SHL: A << 1
    builder.addNewComponent<ShiftLeftLogical8>("OP_SHL");

    // 0x7 SHR: A >> 1 (logical)
    builder.addNewComponent<ShiftRightLogical8>("OP_SHR");

    // 0x8 SRA: A >> 1 (arithmetic)
    builder.addNewComponent<ShiftRightArithmetic8>("OP_SRA");

    // 0x9 INC: A + 1 (uses B=0, Cin=1)
    builder.addNewComponent<Incrementer8>("OP_INC");

    // 0xA DEC: A - 1 (uses B=0xFF, Cin=0)
    builder.addNewComponent<Decrementer8>("OP_DEC");

    // 0xB NEG: -A (uses B=0, Cin=1)
    builder.addNewComponent<TwosComplement8>("OP_NEG");

    // 0xC PASS_A: Use a buffer (BitSplitter + BitJoiner pass-through)
    // We'll just route A directly to the mux

    // 0xD PASS_B: Route B directly to the mux

    // 0xE CMP: Compare A and B - reuse SUB for flags, result = A - B
    // We'll use the SUB result for CMP too (same operation, just for flags)

    // 0xF ZERO: Constant 0 output (use CONST_ZERO)

    // ========== Wire Inputs to Operation Units ==========

    // Split A input for fan-out to all units
    builder.addNewComponent<BitSplitter<8>>("SPLIT_A");
    builder.addNewWire<8>("a_to_splitter",
        builder.getInputPin<8>("A"),
        {builder.getInputPin<BitSplitter<8>, 8>("SPLIT_A", "IN")});

    // Rejoin A for each unit that needs 8-bit A
    // We need multiple BitJoiners because each output can only have one wire
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_ADD");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_SUB");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_AND");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_OR");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_XOR");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_NOT");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_SHL");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_SHR");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_SRA");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_INC");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_DEC");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_NEG");
    builder.addNewComponent<BitJoiner<8>>("JOIN_A_PASS");

    // Wire split A bits to all joiners (fan-out from each split bit)
    for (int i = 0; i < 8; i++) {
        std::string bit = std::to_string(i);
        builder.addNewWire("a_bit_" + bit + "_fanout",
            builder.getOutputPin<BitSplitter<8>>("SPLIT_A", "OUT_" + bit),
            {builder.getInputPin<BitJoiner<8>>("JOIN_A_ADD", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_SUB", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_AND", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_OR", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_XOR", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_NOT", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_SHL", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_SHR", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_SRA", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_INC", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_DEC", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_NEG", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_A_PASS", "IN_" + bit)});
    }

    // Split B input for fan-out
    builder.addNewComponent<BitSplitter<8>>("SPLIT_B");
    builder.addNewWire<8>("b_to_splitter",
        builder.getInputPin<8>("B"),
        {builder.getInputPin<BitSplitter<8>, 8>("SPLIT_B", "IN")});

    // Rejoin B for each unit that needs 8-bit B
    builder.addNewComponent<BitJoiner<8>>("JOIN_B_ADD");
    builder.addNewComponent<BitJoiner<8>>("JOIN_B_SUB");
    builder.addNewComponent<BitJoiner<8>>("JOIN_B_AND");
    builder.addNewComponent<BitJoiner<8>>("JOIN_B_OR");
    builder.addNewComponent<BitJoiner<8>>("JOIN_B_XOR");
    builder.addNewComponent<BitJoiner<8>>("JOIN_B_PASS");

    for (int i = 0; i < 8; i++) {
        std::string bit = std::to_string(i);
        builder.addNewWire("b_bit_" + bit + "_fanout",
            builder.getOutputPin<BitSplitter<8>>("SPLIT_B", "OUT_" + bit),
            {builder.getInputPin<BitJoiner<8>>("JOIN_B_ADD", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_B_SUB", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_B_AND", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_B_OR", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_B_XOR", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_B_PASS", "IN_" + bit)});
    }

    // ========== Connect A inputs to operation units ==========

    // ADD: A + B + Cin(0)
    builder.addNewWire<8>("joined_a_to_add",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_ADD", "OUT"),
        {builder.getInputPin<Adder8, 8>("OP_ADD", "A")});
    builder.addNewWire<8>("joined_b_to_add",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_B_ADD", "OUT"),
        {builder.getInputPin<Adder8, 8>("OP_ADD", "B")});
    builder.addNewWire("gnd_to_add_cin",
        builder.getOutputPin<Ground>("GND_ADD_CIN", "OUT"),
        {builder.getInputPin<Adder8>("OP_ADD", "Cin")});

    // SUB: A - B (Cin=1 for subtraction)
    builder.addNewWire<8>("joined_a_to_sub",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_SUB", "OUT"),
        {builder.getInputPin<Subtractor8, 8>("OP_SUB", "A")});
    builder.addNewWire<8>("joined_b_to_sub",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_B_SUB", "OUT"),
        {builder.getInputPin<Subtractor8, 8>("OP_SUB", "B")});
    builder.addNewWire("vcc_to_sub_cin",
        builder.getOutputPin<Vcc>("VCC_SUB_CIN", "OUT"),
        {builder.getInputPin<Subtractor8>("OP_SUB", "Cin")});

    // AND, OR, XOR: A op B
    builder.addNewWire<8>("joined_a_to_and",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_AND", "OUT"),
        {builder.getInputPin<AND8, 8>("OP_AND", "A")});
    builder.addNewWire<8>("joined_b_to_and",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_B_AND", "OUT"),
        {builder.getInputPin<AND8, 8>("OP_AND", "B")});

    builder.addNewWire<8>("joined_a_to_or",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_OR", "OUT"),
        {builder.getInputPin<OR8, 8>("OP_OR", "A")});
    builder.addNewWire<8>("joined_b_to_or",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_B_OR", "OUT"),
        {builder.getInputPin<OR8, 8>("OP_OR", "B")});

    builder.addNewWire<8>("joined_a_to_xor",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_XOR", "OUT"),
        {builder.getInputPin<XOR8, 8>("OP_XOR", "A")});
    builder.addNewWire<8>("joined_b_to_xor",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_B_XOR", "OUT"),
        {builder.getInputPin<XOR8, 8>("OP_XOR", "B")});

    // NOT: ~A
    builder.addNewWire<8>("joined_a_to_not",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_NOT", "OUT"),
        {builder.getInputPin<NOT8, 8>("OP_NOT", "A")});

    // SHL, SHR, SRA: shift A
    builder.addNewWire<8>("joined_a_to_shl",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_SHL", "OUT"),
        {builder.getInputPin<ShiftLeftLogical8, 8>("OP_SHL", "A")});
    builder.addNewWire<8>("joined_a_to_shr",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_SHR", "OUT"),
        {builder.getInputPin<ShiftRightLogical8, 8>("OP_SHR", "A")});
    builder.addNewWire<8>("joined_a_to_sra",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_SRA", "OUT"),
        {builder.getInputPin<ShiftRightArithmetic8, 8>("OP_SRA", "A")});

    // INC: A + 1 (B=0, Cin=1)
    builder.addNewWire<8>("joined_a_to_inc",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_INC", "OUT"),
        {builder.getInputPin<Incrementer8, 8>("OP_INC", "A")});
    builder.addNewWire<8>("const_zero_to_inc_b",
        builder.getOutputPin<BitJoiner<8>, 8>("CONST_ZERO_INC", "OUT"),
        {builder.getInputPin<Incrementer8, 8>("OP_INC", "B")});
    builder.addNewWire("vcc_to_inc_cin",
        builder.getOutputPin<Vcc>("VCC_INC_CIN", "OUT"),
        {builder.getInputPin<Incrementer8>("OP_INC", "Cin")});

    // DEC: A - 1 (B=0xFF, Cin=0)
    builder.addNewWire<8>("joined_a_to_dec",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_DEC", "OUT"),
        {builder.getInputPin<Decrementer8, 8>("OP_DEC", "A")});
    builder.addNewWire<8>("const_ff_to_dec_b",
        builder.getOutputPin<BitJoiner<8>, 8>("CONST_FF", "OUT"),
        {builder.getInputPin<Decrementer8, 8>("OP_DEC", "B")});
    builder.addNewWire("gnd_to_dec_cin",
        builder.getOutputPin<Ground>("GND_DEC_CIN", "OUT"),
        {builder.getInputPin<Decrementer8>("OP_DEC", "Cin")});

    // NEG: -A = ~A + 1 (B=0, Cin=1)
    builder.addNewWire<8>("joined_a_to_neg",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_NEG", "OUT"),
        {builder.getInputPin<TwosComplement8, 8>("OP_NEG", "A")});
    builder.addNewWire<8>("const_zero_to_neg_b",
        builder.getOutputPin<BitJoiner<8>, 8>("CONST_ZERO_NEG", "OUT"),
        {builder.getInputPin<TwosComplement8, 8>("OP_NEG", "B")});
    builder.addNewWire("vcc_to_neg_cin",
        builder.getOutputPin<Vcc>("VCC_NEG_CIN", "OUT"),
        {builder.getInputPin<TwosComplement8>("OP_NEG", "Cin")});

    // ========== OP Signal Fan-out ==========
    // Split OP into individual bits, then rejoin for each mux that needs it
    builder.addNewComponent<BitSplitter<4>>("SPLIT_OP");
    builder.addNewWire<4>("op_to_splitter",
        builder.getInputPin<4>("OP"),
        {builder.getInputPin<BitSplitter<4>, 4>("SPLIT_OP", "IN")});

    // Create joiners for each destination that needs the 4-bit OP
    builder.addNewComponent<BitJoiner<4>>("JOIN_OP_RESULT");
    builder.addNewComponent<BitJoiner<4>>("JOIN_OP_CARRY");
    builder.addNewComponent<BitJoiner<4>>("JOIN_OP_OVERFLOW");

    // Fan-out each OP bit to all joiners
    for (int i = 0; i < 4; i++) {
        std::string bit = std::to_string(i);
        builder.addNewWire("op_bit_" + bit + "_fanout",
            builder.getOutputPin<BitSplitter<4>>("SPLIT_OP", "OUT_" + bit),
            {builder.getInputPin<BitJoiner<4>>("JOIN_OP_RESULT", "IN_" + bit),
             builder.getInputPin<BitJoiner<4>>("JOIN_OP_CARRY", "IN_" + bit),
             builder.getInputPin<BitJoiner<4>>("JOIN_OP_OVERFLOW", "IN_" + bit)});
    }

    // ========== Result Multiplexer (16:1 8-bit) ==========
    builder.addNewComponent<Mux16to1_8bit>("RESULT_MUX");

    // Wire OP to result mux select (using joined signal)
    builder.addNewWire<4>("joined_op_to_result_mux",
        builder.getOutputPin<BitJoiner<4>, 4>("JOIN_OP_RESULT", "OUT"),
        {builder.getInputPin<Mux16to1_8bit, 4>("RESULT_MUX", "SEL")});

    // Wire all 16 results to mux inputs
    // IN0 = ADD result
    builder.addNewWire<8>("add_result_to_mux",
        builder.getOutputPin<Adder8, 8>("OP_ADD", "Sum"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN0")});

    // IN1 = SUB result
    builder.addNewWire<8>("sub_result_to_mux",
        builder.getOutputPin<Subtractor8, 8>("OP_SUB", "Result"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN1")});

    // IN2 = AND result
    builder.addNewWire<8>("and_result_to_mux",
        builder.getOutputPin<AND8, 8>("OP_AND", "OUT"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN2")});

    // IN3 = OR result
    builder.addNewWire<8>("or_result_to_mux",
        builder.getOutputPin<OR8, 8>("OP_OR", "OUT"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN3")});

    // IN4 = XOR result
    builder.addNewWire<8>("xor_result_to_mux",
        builder.getOutputPin<XOR8, 8>("OP_XOR", "OUT"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN4")});

    // IN5 = NOT result
    builder.addNewWire<8>("not_result_to_mux",
        builder.getOutputPin<NOT8, 8>("OP_NOT", "OUT"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN5")});

    // IN6 = SHL result
    builder.addNewWire<8>("shl_result_to_mux",
        builder.getOutputPin<ShiftLeftLogical8, 8>("OP_SHL", "Result"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN6")});

    // IN7 = SHR result
    builder.addNewWire<8>("shr_result_to_mux",
        builder.getOutputPin<ShiftRightLogical8, 8>("OP_SHR", "Result"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN7")});

    // IN8 = SRA result
    builder.addNewWire<8>("sra_result_to_mux",
        builder.getOutputPin<ShiftRightArithmetic8, 8>("OP_SRA", "Result"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN8")});

    // IN9 = INC result
    builder.addNewWire<8>("inc_result_to_mux",
        builder.getOutputPin<Incrementer8, 8>("OP_INC", "Result"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN9")});

    // IN10 = DEC result
    builder.addNewWire<8>("dec_result_to_mux",
        builder.getOutputPin<Decrementer8, 8>("OP_DEC", "Result"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN10")});

    // IN11 = NEG result
    builder.addNewWire<8>("neg_result_to_mux",
        builder.getOutputPin<TwosComplement8, 8>("OP_NEG", "Result"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN11")});

    // IN12 = PASS_A (A unchanged)
    builder.addNewWire<8>("pass_a_to_mux",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_A_PASS", "OUT"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN12")});

    // IN13 = PASS_B (B unchanged)
    builder.addNewWire<8>("pass_b_to_mux",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_B_PASS", "OUT"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN13")});

    // IN14 = CMP (same as SUB result, for flags)
    // Need another copy of SUB result - use the same Subtractor output routed to a different mux input
    // Actually, we already wired SUB result to IN1. For CMP, we reuse the same circuit logic
    // But we need a separate wire to IN14 - let's create a splitter for SUB result
    builder.addNewComponent<BitSplitter<8>>("SPLIT_SUB_RESULT");
    builder.addNewComponent<BitJoiner<8>>("JOIN_SUB_FOR_CMP");

    // IN14 = CMP (outputs zero since CMP is primarily for flag setting)
    // IN15 = ZERO (constant 0)
    // Both use CONST_ZERO, so consolidate into single wire with multiple sinks
    builder.addNewWire<8>("const_zero_to_mux_14_15",
        builder.getOutputPin<BitJoiner<8>, 8>("CONST_ZERO", "OUT"),
        {builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN14"),
         builder.getInputPin<Mux16to1_8bit, 8>("RESULT_MUX", "IN15")});

    // ========== Wire Result Mux Output to OUT ==========
    // First split the result for flag generation
    builder.addNewComponent<BitSplitter<8>>("SPLIT_RESULT");
    builder.addNewWire<8>("result_mux_to_splitter",
        builder.getOutputPin<Mux16to1_8bit, 8>("RESULT_MUX", "OUT"),
        {builder.getInputPin<BitSplitter<8>, 8>("SPLIT_RESULT", "IN")});

    // Rejoin for output
    builder.addNewComponent<BitJoiner<8>>("JOIN_RESULT_OUT");
    builder.addNewComponent<BitJoiner<8>>("JOIN_RESULT_ZERO");

    // Wire bits 0-6 with fan-out to both joiners
    for (int i = 0; i < 7; i++) {
        std::string bit = std::to_string(i);
        builder.addNewWire("result_bit_" + bit + "_fanout",
            builder.getOutputPin<BitSplitter<8>>("SPLIT_RESULT", "OUT_" + bit),
            {builder.getInputPin<BitJoiner<8>>("JOIN_RESULT_OUT", "IN_" + bit),
             builder.getInputPin<BitJoiner<8>>("JOIN_RESULT_ZERO", "IN_" + bit)});
    }

    // Wire bit 7 with fan-out to joiners and NEGATIVE buffer
    // Use a double NOT gate (buffer) for NEGATIVE because wire propagation to
    // OUTPUT pins as one of multiple sinks doesn't work correctly
    builder.addNewComponent<NOTGate>("NEG_BUF_1");
    builder.addNewComponent<NOTGate>("NEG_BUF_2");

    builder.addNewWire("result_bit_7_fanout",
        builder.getOutputPin<BitSplitter<8>>("SPLIT_RESULT", "OUT_7"),
        {builder.getInputPin<BitJoiner<8>>("JOIN_RESULT_OUT", "IN_7"),
         builder.getInputPin<BitJoiner<8>>("JOIN_RESULT_ZERO", "IN_7"),
         builder.getInputPin<NOTGate>("NEG_BUF_1", "IN")});

    builder.addNewWire("neg_buf_1_to_2",
        builder.getOutputPin<NOTGate>("NEG_BUF_1", "OUT"),
        {builder.getInputPin<NOTGate>("NEG_BUF_2", "IN")});

    builder.addNewWire("neg_buf_to_flag",
        builder.getOutputPin<NOTGate>("NEG_BUF_2", "OUT"),
        {builder.getOutputPin("NEGATIVE")});

    builder.addNewWire<8>("result_to_out",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_RESULT_OUT", "OUT"),
        {builder.getOutputPin<8>("OUT")});

    // ========== ZERO Flag (result == 0) ==========
    builder.addNewComponent<ZeroDetect8>("ZERO_DETECT");
    builder.addNewWire<8>("result_to_zero_detect",
        builder.getOutputPin<BitJoiner<8>, 8>("JOIN_RESULT_ZERO", "OUT"),
        {builder.getInputPin<ZeroDetect8, 8>("ZERO_DETECT", "A")});
    builder.addNewWire("zero_detect_to_flag",
        builder.getOutputPin<ZeroDetect8>("ZERO_DETECT", "ZERO"),
        {builder.getOutputPin("ZERO")});

    // ========== CARRY Flag Multiplexer (16:1 1-bit) ==========
    // Carry flag comes from different sources depending on operation
    builder.addNewComponent<Mux16to1>("CARRY_MUX");

    // Wire OP to carry mux select (using the pre-created joiner)
    builder.addNewWire<4>("joined_op_to_carry_mux",
        builder.getOutputPin<BitJoiner<4>, 4>("JOIN_OP_CARRY", "OUT"),
        {builder.getInputPin<Mux16to1, 4>("CARRY_MUX", "SEL")});

    // Wire carry sources (Ground for ops without carry, actual carry for arithmetic)
    // IN0 = ADD carry
    builder.addNewWire("add_carry_to_mux",
        builder.getOutputPin<Adder8>("OP_ADD", "Cout"),
        {builder.getInputPin<Mux16to1>("CARRY_MUX", "IN0")});

    // IN1 = SUB carry (borrow indicator)
    builder.addNewWire("sub_carry_to_mux",
        builder.getOutputPin<Subtractor8>("OP_SUB", "Cout"),
        {builder.getInputPin<Mux16to1>("CARRY_MUX", "IN1")});

    // IN2-IN5, IN12-IN15 = Operations without carry output - use single ground wire
    // (Logic ops, PASS_A, PASS_B, CMP, ZERO all output 0 for carry)
    builder.addNewWire("gnd_to_carry_unused",
        builder.getOutputPin<Ground>("GND_CARRY_MUX", "OUT"),
        {builder.getInputPin<Mux16to1>("CARRY_MUX", "IN2"),
         builder.getInputPin<Mux16to1>("CARRY_MUX", "IN3"),
         builder.getInputPin<Mux16to1>("CARRY_MUX", "IN4"),
         builder.getInputPin<Mux16to1>("CARRY_MUX", "IN5"),
         builder.getInputPin<Mux16to1>("CARRY_MUX", "IN12"),
         builder.getInputPin<Mux16to1>("CARRY_MUX", "IN13"),
         builder.getInputPin<Mux16to1>("CARRY_MUX", "IN14"),
         builder.getInputPin<Mux16to1>("CARRY_MUX", "IN15")});

    // IN6 = SHL carry (bit shifted out)
    builder.addNewWire("shl_carry_to_mux",
        builder.getOutputPin<ShiftLeftLogical8>("OP_SHL", "Carry"),
        {builder.getInputPin<Mux16to1>("CARRY_MUX", "IN6")});

    // IN7 = SHR carry (bit shifted out)
    builder.addNewWire("shr_carry_to_mux",
        builder.getOutputPin<ShiftRightLogical8>("OP_SHR", "Carry"),
        {builder.getInputPin<Mux16to1>("CARRY_MUX", "IN7")});

    // IN8 = SRA carry (bit shifted out)
    builder.addNewWire("sra_carry_to_mux",
        builder.getOutputPin<ShiftRightArithmetic8>("OP_SRA", "Carry"),
        {builder.getInputPin<Mux16to1>("CARRY_MUX", "IN8")});

    // IN9 = INC carry
    builder.addNewWire("inc_carry_to_mux",
        builder.getOutputPin<Incrementer8>("OP_INC", "Cout"),
        {builder.getInputPin<Mux16to1>("CARRY_MUX", "IN9")});

    // IN10 = DEC borrow
    builder.addNewWire("dec_carry_to_mux",
        builder.getOutputPin<Decrementer8>("OP_DEC", "Bout"),
        {builder.getInputPin<Mux16to1>("CARRY_MUX", "IN10")});

    // IN11 = NEG carry
    builder.addNewWire("neg_carry_to_mux",
        builder.getOutputPin<TwosComplement8>("OP_NEG", "Cout"),
        {builder.getInputPin<Mux16to1>("CARRY_MUX", "IN11")});

    // Wire carry mux output to CARRY flag
    builder.addNewWire("carry_mux_to_flag",
        builder.getOutputPin<Mux16to1>("CARRY_MUX", "OUT"),
        {builder.getOutputPin("CARRY")});

    // ========== OVERFLOW Flag Multiplexer (16:1 1-bit) ==========
    builder.addNewComponent<Mux16to1>("OVERFLOW_MUX");

    builder.addNewWire<4>("joined_op_to_overflow_mux",
        builder.getOutputPin<BitJoiner<4>, 4>("JOIN_OP_OVERFLOW", "OUT"),
        {builder.getInputPin<Mux16to1, 4>("OVERFLOW_MUX", "SEL")});

    // Wire overflow sources
    // IN0, IN2-IN8, IN12-IN15 = Operations without overflow output - use single ground wire
    // (ADD, logic ops, shifts, PASS_A, PASS_B, CMP, ZERO all output 0 for overflow)
    builder.addNewWire("gnd_to_overflow_unused",
        builder.getOutputPin<Ground>("GND_OVERFLOW_MUX", "OUT"),
        {builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN0"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN2"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN3"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN4"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN5"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN6"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN7"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN8"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN12"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN13"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN14"),
         builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN15")});

    // IN1 = SUB overflow
    builder.addNewWire("sub_overflow_to_mux",
        builder.getOutputPin<Subtractor8>("OP_SUB", "Overflow"),
        {builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN1")});

    // IN9 = INC overflow
    builder.addNewWire("inc_overflow_to_mux",
        builder.getOutputPin<Incrementer8>("OP_INC", "Overflow"),
        {builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN9")});

    // IN10 = DEC overflow
    builder.addNewWire("dec_overflow_to_mux",
        builder.getOutputPin<Decrementer8>("OP_DEC", "Overflow"),
        {builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN10")});

    // IN11 = NEG overflow
    builder.addNewWire("neg_overflow_to_mux",
        builder.getOutputPin<TwosComplement8>("OP_NEG", "Overflow"),
        {builder.getInputPin<Mux16to1>("OVERFLOW_MUX", "IN11")});

    // Wire overflow mux output to OVERFLOW flag
    builder.addNewWire("overflow_mux_to_flag",
        builder.getOutputPin<Mux16to1>("OVERFLOW_MUX", "OUT"),
        {builder.getOutputPin("OVERFLOW")});
}
