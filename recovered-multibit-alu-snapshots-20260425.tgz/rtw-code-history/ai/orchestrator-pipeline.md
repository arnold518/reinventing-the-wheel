## Concepts and invariants

### Task = unit of work (root or subtask)

Every task has:

* `spec.md` (what)
* `plan_contract.md` (how: fixed design / implementation decisions)
* `tests_plan.md` (goals + tests to add; planner may write actual test code)
* `status` + counters
* `parent_id`, `child_ids`

### Two-part completion rule (critical)

A task is **DONE** iff:

1. **All subtasks are DONE**, and
2. **This task’s own implementation has passed verification**

So “subtasks completed” is necessary but not sufficient.

### “No refiring subtasks”

Once subtasks are DONE, the parent never re-enqueues them because parent verification failed. Parent loops only on its own impl/verify.

---

## Filesystem pipeline structure (high-level)

Folders remain:

* `tasks/inbox/` new roots you drop
* `tasks/ready/` runnable tasks
* `tasks/running/` claimed
* `tasks/blocked/` needs you
* `tasks/done/`, `tasks/failed/`
* `work/<task_id>/` per-task artifacts + repo worktree

---

## Task state machine (with explicit barrier)

Use these states:

1. `NEW`
2. `PLANNING`
3. `ENQUEUING_CHILDREN` (brief, can be part of planning)
4. `WAITING_CHILDREN`
5. `IMPLEMENTING_SELF`
6. `VERIFYING_SELF`
7. `DONE`
8. `BLOCKED`
9. `FAILED`

**Barrier logic:** you can’t enter `IMPLEMENTING_SELF` until all children are `DONE`.

---

## Full pipeline algorithm

### 0) Ingest (roots)

When you drop a root spec into `inbox/`:

1. Orchestrator assigns `task_id`, creates `work/<task_id>/`
2. Copies spec into `work/<task_id>/spec.md`
3. Initializes status to `NEW`
4. Moves it to `tasks/ready/`

---

## 1) Planning phase (Planner agent)

Triggered when task state is `NEW` or missing contract.

Planner responsibilities (explicitly matching your requirements):

### 1A) Decide decomposition (subtasks or not)

* If split needed:

  * Planner produces child **task specs** (each becomes its own task instance).

### 1B) Fix implementation details for *this task*

Planner writes `plan_contract.md` containing:

* what the parent itself will implement (often integration)
* key technical decisions: interfaces, files/targets touched, constraints
* what is delegated to children vs parent

### 1C) Fix goals and tests for *this task*

Planner writes `tests_plan.md`:

* acceptance criteria (what “done” means)
* if tests apply:

  * planner **adds/writes** the required test code as part of this task’s plan (or explicitly delegates test-writing to a child task if that’s cleaner)
  * list edge cases to cover

> The key is: the planner doesn’t just say “add tests”; it specifies them precisely, and can directly implement them via the implementation step.

### Planning outputs

* `plan_contract.md`
* `tests_plan.md`
* `children_specs[]` (maybe empty)
* (optional) `requires_children_first = true` (default true in your model)

### Orchestrator actions after planning

1. Create/enqueue child tasks (if any):

   * each child gets its own `work/<child_id>/spec.md`, `status=NEW`, `parent_id=<this>`
   * drop into `tasks/ready/`
2. Transition parent state:

   * If it has children: parent → `WAITING_CHILDREN`
   * Else: parent → `IMPLEMENTING_SELF` and enqueue

**Important:** In your chosen model, parent self-implementation begins after children are done, so parent generally goes to `WAITING_CHILDREN` when children exist.

---

## 2) Child execution (recursive)

Children are just tasks. They go through:

* plan → (wait children) → implement self → verify self → done

This naturally recurses.

---

## 3) Parent waiting barrier

When parent is `WAITING_CHILDREN`, it is not runnable until all children are `DONE`.

### Wake-up algorithm

Whenever any task becomes `DONE`:

* if it has a `parent_id`, orchestrator checks that parent’s `child_ids`
* if **all** are `DONE`, then:

  * parent transitions to `IMPLEMENTING_SELF`
  * parent is enqueued into `tasks/ready/`

This is event-driven and prevents polling.

---

## 4) Parent self implementation cycle (Implement agent)

Triggered for state `IMPLEMENTING_SELF`.

Inputs:

* `spec.md`
* `plan_contract.md`
* `tests_plan.md`
* plus (optional) summaries from children (so parent knows what got delivered)

Implementer does exactly what’s in the contract:

* integration code
* any required test code for the parent task (planner-defined)
* build/config glue if contract includes it

Then:

* Orchestrator runs the build/compile step (whatever command you’ve standardized).
* If build fails:

  * store build log
  * increment `impl_attempts`
  * if attempts exceeded → `FAILED`
  * else stay `IMPLEMENTING_SELF` and requeue parent

If build succeeds:

* parent → `VERIFYING_SELF` and requeue

---

## 5) Parent self verification cycle (Verifying agent)

Triggered for `VERIFYING_SELF`.

Verifier checks against planner artifacts:

* Did we satisfy the contract?
* Are acceptance criteria satisfied?
* Run the test suite (e.g., via `ctest`) as evidence, but keep this conceptual.

Outcomes:

### PASS

* Parent → `DONE`
* If parent is root, trigger finalization/report.

### FAIL

* Parent → `IMPLEMENTING_SELF`
* Store verifier notes + failing outputs
* Increment `verify_attempts`
* If attempts exceeded:

  * either `FAILED` or `BLOCKED` (if it needs a decision from you)
* **No subtasks are requeued.** They remain DONE.

That’s your rule, and it keeps the loop focused.

### BLOCKED

* Parent → `BLOCKED` with clear questions (e.g., expected behavior vs actual)

---

## 6) Finalization (Finalizer agent)

Finalizer runs when a **root** task is `DONE`.

It must include subtask work:

* traverse subtree (root → descendants)
* aggregate:

  * each task’s summary
  * key diffs
  * test evidence outcomes
* write `root_report.md` and place into `approvals/` (or just `done/` if no approval gate)

---

## Recommended planner policy (so parent/child division is crisp)

To avoid confusion, planner should always declare:

1. **What children deliver** (outputs, interfaces, files)
2. **What parent delivers** (integration + top-level tests)
3. **What parent verifies** (integration acceptance)

This makes it obvious why the parent’s tests can fail even if children passed: because integration is a separate concern.

---

## One more practical safeguard: don’t let parent “inherit” child failures late

Even though parent starts after children are DONE, still record a minimal “child completion summary” into parent workspace when each child finishes (e.g., a short `child_result.md`). It helps parent implementer integrate without reopening children.

---

### The whole pipeline in one sentence

**Plan (split + fixed impl details + goals/tests) → run children to DONE → parent implement+write tests → parent verify (ctest evidence) → if fail loop on parent only → root final report aggregates subtree.**

If you want, next we can define the *exact contents* of `plan_contract.md` and `tests_plan.md` templates so your agents behave consistently without ambiguity.
