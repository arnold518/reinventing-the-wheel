# 8-Bit ALU Implementation Roadmap

**Last Updated**: February 2026
**Status**: Complete — all 16 operations implemented and tested
**Source**: `include/modules/composite/ALU8.hpp`, `src/modules/composite/ALU8.cpp`

---

## Table of Contents

1. [Overview](#overview)
2. [Completed Components](#completed-components)
3. [ALU8 Specification](#alu8-specification)
4. [Internal Architecture](#internal-architecture)
5. [Known Limitations](#known-limitations)
6. [Testing](#testing)

---

## Overview

ALU8 is a fully functional 8-bit Arithmetic Logic Unit built from gate-level components. The design prioritizes educational value and visualization over optimization.

**Design Philosophy:**
- All 16 operation units compute in parallel simultaneously
- A `Mux16to1_8bit` selects the result based on the 4-bit opcode
- Separate `Mux16to1` (1-bit) instances select carry and overflow flags
- Flag logic (ZERO, NEGATIVE) derived from the selected result
- No shared or optimized paths — each operation has dedicated hardware

---

## Completed Components

### Phase 1: Logic Operations ✓
| Component | Function | Inputs | Outputs |
|-----------|----------|--------|---------|
| AND8 | A & B | A\<8\>, B\<8\> | OUT\<8\> |
| OR8 | A \| B | A\<8\>, B\<8\> | OUT\<8\> |
| XOR8 | A ^ B | A\<8\>, B\<8\> | OUT\<8\> |
| NOT8 | ~A | A\<8\> | OUT\<8\> |
| NAND8 | ~(A & B) | A\<8\>, B\<8\> | OUT\<8\> |
| NOR8 | ~(A \| B) | A\<8\>, B\<8\> | OUT\<8\> |

### Phase 2: Multiplexers ✓
| Component | Function | Select Bits |
|-----------|----------|-------------|
| Mux2to1 | 2:1 select | 1 |
| Mux4to1 | 4:1 select | 2 |
| Mux8to1 | 8:1 select | 3 |
| Mux16to1 | 16:1 select (1-bit) | 4 |
| Mux2to1_8bit | 8-bit 2:1 | 1 |
| Mux4to1_8bit | 8-bit 4:1 | 2 |
| Mux8to1_8bit | 8-bit 8:1 | 3 |
| Mux16to1_8bit | 8-bit 16:1 | 4 |

### Phase 3: Arithmetic Operations ✓
| Component | Function | Inputs | Outputs |
|-----------|----------|--------|---------|
| Adder8 | A + B + Cin | A\<8\>, B\<8\>, Cin | Sum\<8\>, Cout |
| Subtractor8 | A - B | A\<8\>, B\<8\>, Cin=1 | Result\<8\>, Cout, Overflow |
| SubtractorWithBorrow8 | A - B - Bin | A\<8\>, B\<8\>, Bin | Result\<8\>, Bout, Overflow |
| Incrementer8 | A + 1 | A\<8\>, B\<8\>=0, Cin=1 | Result\<8\>, Cout, Overflow |
| Decrementer8 | A - 1 | A\<8\>, B\<8\>=0xFF, Cin=0 | Result\<8\>, Bout, Overflow |
| TwosComplement8 | -A | A\<8\>, B\<8\>=0, Cin=1 | Result\<8\>, Cout, Overflow |

### Phase 4: Comparison Operations ✓
*(Built but not used in ALU8's mux. Available for future use.)*

| Component | Function | Inputs | Outputs |
|-----------|----------|--------|---------|
| EqualityChecker8 | A == B | A\<8\>, B\<8\> | EQ |
| Comparator8 | Unsigned compare | A\<8\>, B\<8\> | LT, GT, EQ |
| SignedComparator8 | Signed compare | A\<8\>, B\<8\> | SLT, SGT, SEQ |

### Phase 5: Shift Operations ✓
| Component | Function | Inputs | Outputs |
|-----------|----------|--------|---------|
| ShiftLeftLogical8 | A << 1 | A\<8\> | Result\<8\>, Carry |
| ShiftRightLogical8 | A >> 1 (logical) | A\<8\> | Result\<8\>, Carry |
| ShiftRightArithmetic8 | A >> 1 (arithmetic) | A\<8\> | Result\<8\>, Carry |

### Utility Components ✓
| Component | Function |
|-----------|----------|
| Ground | Constant LOW output |
| Vcc | Constant HIGH output |
| ZeroDetect8 | HIGH when 8-bit input == 0x00 |
| BitSplitter\<N\> | Split Pin\<N\> to N× Pin\<1\> |
| BitJoiner\<N\> | Join N× Pin\<1\> to Pin\<N\> |

---

## ALU8 Specification

### External Interface

```
                    ┌─────────────────────┐
        A<8> ──────►│                     │──────► OUT<8>
        B<8> ──────►│       ALU8          │──────► ZERO
        OP<4> ─────►│                     │──────► CARRY
                    │                     │──────► OVERFLOW
                    │                     │──────► NEGATIVE
                    └─────────────────────┘
```

### Inputs

| Pin | Width | Description |
|-----|-------|-------------|
| A | 8 | First operand |
| B | 8 | Second operand |
| OP | 4 | Operation select (0–15) |

### Outputs

| Pin | Width | Description |
|-----|-------|-------------|
| OUT | 8 | Operation result |
| ZERO | 1 | HIGH when OUT == 0x00 |
| CARRY | 1 | Carry/borrow/shift-out (operation-dependent) |
| OVERFLOW | 1 | Equals CARRY for SUB/INC/DEC/NEG; always 0 for ADD and logical ops (see Known Limitations) |
| NEGATIVE | 1 | OUT[7] — the sign bit |

### Operation Encoding (4-bit Opcode)

This is the **as-implemented** opcode table. It differs from the original draft spec (which planned SLT/SLTU/NAND/NOR at 0x9–0xF).

| OP[3:0] | Hex | Mnemonic | Function | Component | Flags |
|---------|-----|----------|----------|-----------|-------|
| 0000 | 0x0 | ADD | A + B | Adder8 (Cin=0) | Z,C,N |
| 0001 | 0x1 | SUB | A - B | Subtractor8 (Cin=1) | Z,C,V,N |
| 0010 | 0x2 | AND | A & B | AND8 | Z,N |
| 0011 | 0x3 | OR  | A \| B | OR8 | Z,N |
| 0100 | 0x4 | XOR | A ^ B | XOR8 | Z,N |
| 0101 | 0x5 | NOT | ~A | NOT8 | Z,N |
| 0110 | 0x6 | SHL | A << 1 | ShiftLeftLogical8 | Z,C,N |
| 0111 | 0x7 | SHR | A >> 1 (logical) | ShiftRightLogical8 | Z,C,N |
| 1000 | 0x8 | SRA | A >> 1 (arithmetic) | ShiftRightArithmetic8 | Z,C,N |
| 1001 | 0x9 | INC | A + 1 | Incrementer8 (B=0, Cin=1) | Z,C,V,N |
| 1010 | 0xA | DEC | A - 1 | Decrementer8 (B=0xFF, Cin=0) | Z,C,V,N |
| 1011 | 0xB | NEG | -A | TwosComplement8 (B=0, Cin=1) | Z,C,V,N |
| 1100 | 0xC | PASS_A | A unchanged | (wire through JOIN_A_PASS) | Z,N |
| 1101 | 0xD | PASS_B | B unchanged | (wire through JOIN_B_PASS) | Z,N |
| 1110 | 0xE | CMP | Compare (flags only) | CONST_ZERO (see limitations) | Z |
| 1111 | 0xF | ZERO | Constant 0 | CONST_ZERO | Z |

### Flag Behavior

| Flag | Set When | Active For |
|------|----------|------------|
| ZERO (Z) | OUT == 0x00 | All ops |
| NEGATIVE (N) | OUT[7] == 1 | All ops |
| CARRY (C) | See table below | ADD, SUB, SHL, SHR, SRA, INC, DEC, NEG |
| OVERFLOW (V) | See Known Limitations | SUB, INC, DEC, NEG (equals CARRY; always 0 for ADD) |

**CARRY semantics per operation:**

| Op | CARRY meaning | CARRY=1 when | CARRY=0 when |
|----|---------------|--------------|--------------|
| ADD | Unsigned carry out of bit 7 | Sum > 255 | Sum ≤ 255 |
| SUB | No-borrow indicator (Cout of A+~B+1) | A ≥ B (unsigned) | A < B (unsigned) |
| SHL | A[7] shifted out | A[7] was 1 | A[7] was 0 |
| SHR | A[0] shifted out | A[0] was 1 | A[0] was 0 |
| SRA | A[0] shifted out | A[0] was 1 | A[0] was 0 |
| INC | Unsigned carry out | A == 0xFF (wraps to 0) | A < 0xFF |
| DEC | No-borrow indicator (Cout of A+0xFF+0) | A ≥ 1 (no underflow) | A == 0x00 (underflows) |
| NEG | Carry out of ~A+1 | A == 0x00 (NEG(0)=0) | A ≠ 0x00 |
| Others | — | never | always |

---

## Internal Architecture

### Block Diagram

```
                           A<8>              B<8>
                             │                 │
                   ┌─────────▼─────────────────▼─────────┐
                   │    BitSplitter<8>  BitSplitter<8>    │
                   │    (SPLIT_A)       (SPLIT_B)         │
                   │    Fan-out to      Fan-out to        │
                   │    13× JOIN_A_*    6× JOIN_B_*       │
                   └─────────┬─────────────────┬──────────┘
                             │                 │
         ┌───────────────────┼─────────────────┼─────────────────────┐
         │  Constant Sources │                 │                     │
         │  CONST_ZERO(0x00) │                 │                     │
         │  CONST_FF(0xFF)   │                 │                     │
         │  GND / VCC        │                 │                     │
         └───────┬───────────┼─────────────────┼─────────────────────┘
                 │           │                 │
      ┌──────────▼───────────▼─────────────────▼──────────────────────┐
      │                  Operation Units (all compute in parallel)     │
      │                                                                │
      │  OP_ADD (Adder8, Cin=GND)     OP_SHL (ShiftLeftLogical8)      │
      │  OP_SUB (Subtractor8, Cin=VCC) OP_SHR (ShiftRightLogical8)   │
      │  OP_AND (AND8)                OP_SRA (ShiftRightArithmetic8)  │
      │  OP_OR  (OR8)                 OP_INC (Incrementer8)           │
      │  OP_XOR (XOR8)                OP_DEC (Decrementer8)           │
      │  OP_NOT (NOT8)                OP_NEG (TwosComplement8)        │
      │  PASS_A (JOIN_A_PASS wire)    PASS_B (JOIN_B_PASS wire)       │
      │  CMP    (CONST_ZERO)          ZERO   (CONST_ZERO)             │
      └──┬─────────────────────┬──────────────────────────────────────┘
         │  8-bit results      │  1-bit carry/overflow signals
         │                     │
  ┌──────▼──────┐    ┌─────────▼──────────┐ ┌──────────────────────┐
  │ Mux16to1   │    │ CARRY_MUX          │ │ OVERFLOW_MUX         │
  │ _8bit      │    │ (Mux16to1, 1-bit)  │ │ (Mux16to1, 1-bit)    │
  │ (RESULT_MUX│◄── │ SEL=OP             │ │ SEL=OP               │
  │  SEL=OP)   │    └─────────┬──────────┘ └──────────┬───────────┘
  └──────┬──────┘             │                        │
         │                    ▼                        ▼
  ┌──────▼──────────┐       CARRY                 OVERFLOW
  │ BitSplitter<8>  │
  │ (SPLIT_RESULT)  │
  └──┬───────────┬──┘
     │           │
  ┌──▼──┐  ┌────▼─────┐
  │JOIN │  │JOIN      │   bit[7] → NOT→NOT → NEGATIVE
  │OUT  │  │RESULT    │
  │<8>  │  │ZERO <8>  │
  └──┬──┘  └────┬─────┘
     │           │
    OUT<8>  ZeroDetect8 → ZERO
```

### Result Mux Slot Assignments

| IN slot | Operation | Source |
|---------|-----------|--------|
| IN0 | ADD | Adder8.Sum |
| IN1 | SUB | Subtractor8.Result |
| IN2 | AND | AND8.OUT |
| IN3 | OR | OR8.OUT |
| IN4 | XOR | XOR8.OUT |
| IN5 | NOT | NOT8.OUT |
| IN6 | SHL | ShiftLeftLogical8.Result |
| IN7 | SHR | ShiftRightLogical8.Result |
| IN8 | SRA | ShiftRightArithmetic8.Result |
| IN9 | INC | Incrementer8.Result |
| IN10 | DEC | Decrementer8.Result |
| IN11 | NEG | TwosComplement8.Result |
| IN12 | PASS_A | JOIN_A_PASS.OUT |
| IN13 | PASS_B | JOIN_B_PASS.OUT |
| IN14 | CMP | CONST_ZERO (0x00) |
| IN15 | ZERO | CONST_ZERO (0x00) |

### Carry/Overflow Mux Slot Assignments

| IN slot | CARRY source | OVERFLOW source |
|---------|-------------|-----------------|
| IN0 (ADD) | Adder8.Cout | GND (no overflow logic for ADD) |
| IN1 (SUB) | Subtractor8.Cout | Subtractor8.Overflow (= Cout) |
| IN2–IN5 (AND/OR/XOR/NOT) | GND | GND |
| IN6 (SHL) | ShiftLeftLogical8.Carry | GND |
| IN7 (SHR) | ShiftRightLogical8.Carry | GND |
| IN8 (SRA) | ShiftRightArithmetic8.Carry | GND |
| IN9 (INC) | Incrementer8.Cout | Incrementer8.Overflow (= Cout) |
| IN10 (DEC) | Decrementer8.Bout | Decrementer8.Overflow (= Bout) |
| IN11 (NEG) | TwosComplement8.Cout | TwosComplement8.Overflow (= Cout) |
| IN12–IN15 (PASS_A/B, CMP, ZERO) | GND | GND |

### Constant Input Wiring for Arithmetic Units

| Unit | A input | B input | Cin input |
|------|---------|---------|-----------|
| OP_ADD | External A | External B | GND (0) |
| OP_SUB | External A | External B | VCC (1) |
| OP_INC | External A | CONST_ZERO_INC (0x00) | VCC (1) |
| OP_DEC | External A | CONST_FF (0xFF) | GND (0) |
| OP_NEG | External A | CONST_ZERO_NEG (0x00) | VCC (1) |

### NEGATIVE Flag Implementation

Result bit 7 drives a double-NOT buffer (NEG_BUF_1 → NEG_BUF_2) before reaching the NEGATIVE output pin. A direct wire from a split bit to an output pin as one of multiple sinks doesn't propagate correctly, so the buffer forces a proper ComponentEval event.

---

## Known Limitations

### 1. ADD has no overflow detection
The OVERFLOW flag is hardwired to GND for the ADD operation. The Adder8 component only produces `Sum` and `Cout`; there is no separate XOR-of-carry-in/carry-out overflow detection. To add it: wire a new overflow logic unit (XOR of carry-in and carry-out of bit 7) and feed its output into OVERFLOW_MUX IN0.

### 2. OVERFLOW = CARRY for SUB, INC, DEC, NEG
All four components (Subtractor8, Incrementer8, Decrementer8, TwosComplement8) wire `Adder8.Cout` to both their `Cout`/`Bout` and `Overflow` output pins using a single fan-out wire. This means OVERFLOW always equals CARRY for these operations, which is **not** correct signed overflow in the general case.

Example failures:
- `NEG(0x80)` → result 0x80, CARRY=0, OVERFLOW=0. True signed overflow = 1 (−(−128) overflows).
- `INC(0x7F)` → result 0x80, CARRY=0, OVERFLOW=0. True signed overflow = 1 (+127+1 overflows).
- `SUB(0x00, 0x80)` → result 0x80, CARRY=0, OVERFLOW=0. True signed overflow = 1 (0−(−128) overflows).

To fix: implement proper overflow detection in each arithmetic component as `carry_in[7] XOR carry_out[7]`.

### 3. CMP is incomplete
CMP (0xE) was intended to expose subtraction flags without producing a visible result. The current implementation wires both CMP and ZERO result mux inputs to `CONST_ZERO`, and both carry/overflow mux inputs to GND. Consequently:
- OUT always = 0x00
- ZERO always = 1, NEGATIVE always = 0
- CARRY always = 0, OVERFLOW always = 0

To implement properly: route `Subtractor8.Cout` and `Subtractor8.Overflow` into CARRY_MUX IN14 and OVERFLOW_MUX IN14, and drive ZERO/NEGATIVE from the actual subtraction result (not from the 0x00 constant in the result mux).

### 4. Fan-out via BitSplitter/BitJoiner chains
The input distribution network (SPLIT_A → 13× JOIN_A_* → each unit) adds substantial simulation depth. Each bit fan-out becomes a wire event followed by 13 component eval events. This is the primary reason ALU8Test takes ~40 seconds.

---

## Testing

### Test File
`src/tests/ALU8Test.cpp` — uses `TruthTableTest` base class.

All 44 truth table rows are verified, covering all 5 outputs (OUT, ZERO, CARRY, OVERFLOW, NEGATIVE) for every row.

### Coverage by Operation

| Op | Cases | What's verified |
|----|-------|-----------------|
| ADD | 6 | Normal, signed boundary, unsigned carry, double-carry |
| SUB | 4 | Normal, zero-result, borrow, signed boundary |
| AND | 2 | Partial mask, zero result |
| OR | 2 | Full mask, zero result |
| XOR | 2 | Self-cancel (zero), complement pattern |
| NOT | 2 | Invert 0xFF and 0x00 |
| SHL | 4 | Normal, carry-out, negative result, carry+negative |
| SHR | 3 | Normal, carry-out+zero, carry-out+nonzero result |
| SRA | 4 | Sign extend negative, positive, all-ones, all-ones carry |
| INC | 3 | Normal, wrap+carry, signed boundary (no carry) |
| DEC | 3 | Normal, underflow, signed boundary |
| NEG | 4 | Normal, NEG(0), NEG(0x80) overflow case, NEG(0xFF) |
| PASS_A | 3 | Normal, zero, negative |
| PASS_B | 3 | Normal, zero, negative |
| CMP | 3 | A>B, A<B, A==B (all verify as-implemented: OUT=0, ZERO=1) |
| ZERO | 1 | Constant zero output |

### Example Verified Rows (actual flag values from ALU8)

```
ADD: A=0xFF, B=0x01 → OUT=0x00, Z=1, C=1, V=0, N=0
ADD: A=0x7F, B=0x01 → OUT=0x80, Z=0, C=0, V=0, N=1  // V=0 despite signed overflow
SUB: A=0x05, B=0x03 → OUT=0x02, Z=0, C=1, V=1, N=0  // C=V=1 (no borrow)
SUB: A=0x00, B=0x01 → OUT=0xFF, Z=0, C=0, V=0, N=1  // C=V=0 (borrow)
SHL: A=0xC0         → OUT=0x80, Z=0, C=1, V=0, N=1
SHR: A=0x03         → OUT=0x01, Z=0, C=1, V=0, N=0
SRA: A=0xFF         → OUT=0xFF, Z=0, C=1, V=0, N=1
INC: A=0xFF         → OUT=0x00, Z=1, C=1, V=1, N=0
DEC: A=0x00         → OUT=0xFF, Z=0, C=0, V=0, N=1  // underflow
NEG: A=0x80         → OUT=0x80, Z=0, C=0, V=0, N=1  // true overflow, not detected
CMP: A=0xFF, B=0x01 → OUT=0x00, Z=1, C=0, V=0, N=0  // always zero (limitation)
```

---

## Success Criteria

- [x] All 16 operations produce correct `OUT` results
- [x] ZERO and NEGATIVE flags correct for all operations
- [x] CARRY flag correct for all operations with carry semantics (ADD, SUB, SHL, SHR, SRA, INC, DEC, NEG)
- [x] Comprehensive test suite — 44 rows, all 5 outputs verified per row
- [x] Documentation complete and accurate
- [ ] OVERFLOW correct for ADD (no overflow logic — always 0)
- [ ] OVERFLOW correct for INC/DEC/NEG (currently equals CARRY, not true signed overflow)
- [ ] CMP exposes subtraction flags (currently outputs constant 0 for all inputs)
