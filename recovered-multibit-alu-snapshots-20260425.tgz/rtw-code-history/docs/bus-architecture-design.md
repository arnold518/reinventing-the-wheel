# Bus Architecture Design Document

## 1. What is a Bus? (Conceptual Model)

### Hardware Perspective
A **bus** in digital systems is:
- **Physically**: A collection of parallel electrical conductors (wires/traces) carrying related signals
- **Logically**: A communication channel for multi-bit information (data, address, control)
- **Functionally**: A shared pathway for transferring values between components

### Examples in Real Hardware
```
8-bit Data Bus:    D[7:0]   - 8 parallel wires carrying one byte
32-bit Address Bus: A[31:0]  - 32 wires specifying memory location
16-bit ALU Output:  Y[15:0]  - 16 wires carrying computation result
```

### Key Properties
1. **Parallelism**: All bits exist simultaneously on separate physical wires
2. **Atomicity**: Often treated as single logical unit (e.g., "instruction" not 32 bits)
3. **Timing**: Individual bits may have slightly different propagation delays
4. **Granularity**: Can be accessed as whole (bus[7:0]) or parts (bus[3:0])

---

## 2. Design Approaches: Three Options

### Option A: Bus as Collection of Single-Bit Wires (Bit-Granular Model)

```
┌─────────────┐                    ┌─────────────┐
│  Component  │                    │  Component  │
│      A      │                    │      B      │
│             │                    │             │
│  Pin "D0" ──┼──► Wire[0] ───────┼──► Pin "D0" │
│  Pin "D1" ──┼──► Wire[1] ───────┼──► Pin "D1" │
│  Pin "D2" ──┼──► Wire[2] ───────┼──► Pin "D2" │
│     ...     │       ...          │     ...     │
│  Pin "D7" ──┼──► Wire[7] ───────┼──► Pin "D7" │
└─────────────┘                    └─────────────┘

Bus<8> = { Wire[0], Wire[1], ..., Wire[7] }
         (convenience container, not simulation entity)
```

**Implementation:**
- Each bit is a separate Pin (D0, D1, D2, ...)
- Each bit is a separate Wire
- Bus class is just a helper container grouping 8 wires
- Simulation events fire per-bit
- Components declare 8 individual pins

**Code Example:**
```cpp
// Component with 8-bit input
class Register8 : public IOComponent {
    Register8() : IOComponent("REG8", [](IOComponent* self) {
        for (int i = 0; i < 8; i++) {
            self->addPin("D" + std::to_string(i), PinType::INPUT);
            self->addPin("Q" + std::to_string(i), PinType::OUTPUT);
        }
    }) {}
};

// Usage:
auto reg = Component::create<Register8>("R0");
auto data_bus = std::make_shared<Bus<8>>("DATA");

// Must connect 8 individual wires
for (int i = 0; i < 8; i++) {
    builder.addNewWire("data_" + std::to_string(i),
        source_pin_array[i],
        {reg->getInputPin("D" + std::to_string(i))});
}
```

**Pros:**
- ✓ Matches physical reality (8 real wires in hardware)
- ✓ Preserves bit-level timing accuracy
- ✓ Can visualize individual bit transitions
- ✓ No changes to existing Wire/Pin/Event model
- ✓ Gate-level components work naturally

**Cons:**
- ✗ 8x more pins for 8-bit data (32x for 32-bit!)
- ✗ Verbose API (must wire 32 connections for 32-bit bus)
- ✗ Simulation overhead (32 events instead of 1)
- ✗ Awkward for components treating data as atomic unit
- ✗ Clutter in visualizer (32 separate wires for one bus)

---

### Option B: Multi-Bit Wires and Pins (Bus-Granular Model)

```
┌─────────────┐                    ┌─────────────┐
│  Component  │                    │  Component  │
│      A      │                    │      B      │
│             │                    │             │
│ Pin "DATA"  │                    │ Pin "DATA"  │
│  [7:0]   ───┼──► Wire<8> ────────┼───► [7:0]   │
│             │   (carries         │             │
│             │    uint8_t)        │             │
└─────────────┘                    └─────────────┘

Bus = Wire  (same entity, not a container)
```

**Implementation:**
- Wire carries multi-bit value (uint64_t instead of LogicValue)
- Pin represents multi-bit port (width property)
- Bus and Wire are same concept
- Single event propagates entire bus value
- Components declare one multi-bit pin

**Code Example:**
```cpp
// Wire changes
class Wire {
    LogicValue value;  // OLD: single bit
    uint64_t value;    // NEW: multi-bit
    size_t width;      // NEW: bit width
};

// Pin changes
class Pin {
    PinType type;      // INPUT/OUTPUT
    size_t width;      // NEW: 1 for single-bit, 8 for byte, etc.
};

// Component with 8-bit input
class Register8 : public IOComponent {
    Register8() : IOComponent("REG8", [](IOComponent* self) {
        self->addPin("D", PinType::INPUT, 8);   // One 8-bit pin
        self->addPin("Q", PinType::OUTPUT, 8);  // One 8-bit pin
    }) {}
};

// Usage:
auto reg = Component::create<Register8>("R0");
auto data_wire = builder.addNewWire("DATA", 8); // 8-bit wire

// Single connection
builder.connectWire(data_wire, source->getOutputPin("DATA"),
                    {reg->getInputPin("D")});
```

**Pros:**
- ✓ Clean API (one pin, one wire for 32-bit bus)
- ✓ Better performance (1 event vs 32 events)
- ✓ Natural for high-level components (CPU, memory)
- ✓ Easier visualization (one wire, show hex value)
- ✓ Matches behavioral modeling

**Cons:**
- ✗ Loses bit-level granularity (can't see individual bit changes)
- ✗ Less accurate timing (all bits change atomically - unrealistic)
- ✗ Major rewrite of Wire/Pin/Event system
- ✗ Breaks existing gate-level components
- ✗ Hard to implement bit manipulation (slicing, concatenation)

---

### Option C: Hybrid Dual-Granularity Model (Recommended)

Support BOTH bit-level and bus-level abstractions, with explicit conversion.

```
GATE LEVEL (Bit Granular):
┌─────────────┐                    ┌─────────────┐
│   XORGate   │                    │   ANDGate   │
│  Pin "A" ───┼──► Wire ───────────┼──► Pin "A"  │ (single bit)
│  Pin "B" ───┼──► Wire ───────────┼──► Pin "B"  │ (single bit)
└─────────────┘                    └─────────────┘

BUS LEVEL (Bus Granular):
┌─────────────┐                    ┌─────────────┐
│     ALU     │                    │   Memory    │
│ Pin "DATA"  │                    │ Pin "DATA"  │
│  [31:0]  ───┼──► BusWire<32> ────┼───► [31:0]  │ (32-bit atomic)
└─────────────┘                    └─────────────┘

CONVERSION (Explicit Boundary):
┌─────────────┐                    ┌─────────────┐
│  Adder8Bit  │                    │ BusPacker   │
│  (8 bit     │                    │             │
│   pins)  ───┼──► Wire[0..7] ─────┼──► BusWire  │
│             │                    │   (packs 8  │
│             │                    │    bits)    │
└─────────────┘                    └─────────────┘
```

**Implementation:**
- Keep current `Wire` (single-bit, LogicValue)
- Add new `BusWire<WIDTH>` (multi-bit, uint64_t)
- Keep current `Pin` (single-bit)
- Add new `BusPin` (multi-bit)
- Provide `BusPacker`/`BusUnpacker` components for conversion

**Class Hierarchy:**
```cpp
// Single-bit (existing)
class Wire {
    LogicValue value;  // HIGH, LOW, UNKNOWN, HIGH_Z
};

class Pin {
    PinType type;      // INPUT/OUTPUT
};

// Multi-bit (new)
template<size_t WIDTH>
class BusWire {
    uint64_t value;
    std::bitset<WIDTH> validity_mask;  // Track which bits are known
};

template<size_t WIDTH>
class BusPin {
    PinType type;
    static constexpr size_t width = WIDTH;
};

// Conversion utilities
class BusPacker : public IOComponent {
    // Inputs: D0, D1, ..., D7 (8 single-bit pins)
    // Output: DATA (one BusPin<8>)

    void evaluate(size_t time, Simulator& sim) override {
        uint8_t packed = 0;
        for (int i = 0; i < 8; i++) {
            if (getInputPin("D" + std::to_string(i))->getValue() == LogicValue::HIGH) {
                packed |= (1 << i);
            }
        }
        getOutputBusPin<8>("DATA")->setValue(packed);
    }
};
```

**Pros:**
- ✓ Best of both worlds
- ✓ Gate-level components: bit-accurate, educational
- ✓ CPU-level components: clean API, performant
- ✓ Explicit conversion makes data flow clear
- ✓ Gradual migration (add BusWire without breaking Wire)

**Cons:**
- ✗ Two parallel systems (more complexity)
- ✗ Need conversion components (overhead)
- ✗ Users must understand two models
- ✗ More code to maintain

---

## 3. Detailed Comparison Matrix

| Aspect | Option A: Bit-Granular | Option B: Bus-Granular | Option C: Hybrid |
|--------|----------------------|----------------------|------------------|
| **API Verbosity** | Very verbose (32 pins) | Clean (1 pin) | Medium (depends on component) |
| **Simulation Speed** | Slow (32x events) | Fast (1 event) | Medium (optimized per level) |
| **Timing Accuracy** | Precise (per-bit) | Coarse (atomic) | Precise at gates, coarse at CPU |
| **Gate-Level Gates** | Natural | Awkward | Natural (use bit-level) |
| **CPU Components** | Awkward | Natural | Natural (use bus-level) |
| **Visualization** | Cluttered (32 wires) | Clean (1 wire) | Clean (buses), detailed (gates) |
| **Implementation Effort** | Low (extend current) | High (rewrite core) | Medium (add parallel system) |
| **Educational Value** | High (see all bits) | Low (abstracted) | High (see both levels) |
| **Backward Compatibility** | Perfect | Breaks everything | Perfect |

---

## 4. Real-World HDL Comparison

### Verilog (Supports Both)
```verilog
// Single-bit
wire clk;
wire reset;

// Multi-bit buses
wire [7:0] data_bus;    // 8-bit bus
wire [31:0] address;     // 32-bit bus

// Can access individual bits
assign data_bus[0] = source_bit;
assign low_nibble = data_bus[3:0];  // Bit slicing
```

### VHDL (Supports Both)
```vhdl
-- Single-bit
signal clk : std_logic;

-- Multi-bit
signal data : std_logic_vector(7 downto 0);
signal addr : unsigned(31 downto 0);

-- Bit manipulation
data(0) <= source_bit;
low_nibble <= data(3 downto 0);
```

**Lesson**: Professional HDLs support BOTH models and allow seamless conversion!

---

## 5. Recommended Approach: Phased Implementation

### Phase 1 (Months 1-3): Option A - Bit-Granular Only
**Why**: Get buses working quickly without major rewrites.

- Implement `Bus<WIDTH>` as container of single-bit wires
- Components create individual pins (D0, D1, ..., D7)
- Provide helper functions to reduce verbosity
- Build: 8-bit adder, 16-bit ALU, simple registers

**Limitations**: 32-bit components will be verbose, simulation slow.

### Phase 2 (Months 4-6): Add Option C - Hybrid Model
**Why**: Enable efficient CPU-level simulation.

- Add `BusWire<WIDTH>` class (multi-bit wires)
- Add `BusPin<WIDTH>` class (multi-bit pins)
- Keep existing `Wire` and `Pin` (backward compatible)
- Build: BusPacker/Unpacker for conversion
- Build: 32-bit ALU using BusWire, Register file using BusWire

**Migration**: Gate-level stays bit-granular, CPU-level uses bus-granular.

### Phase 3 (Months 7+): Optimize with Smart Conversion
**Why**: Minimize conversion overhead.

- Auto-detect when bit-level precision not needed
- Bundle multiple bit-events into bus-events
- Adaptive simulation (gate-level when needed, bus-level for speed)

---

## 6. Concrete Examples

### Example 1: 8-bit Ripple Carry Adder (Gate-Level)

**Option A (Bit-Granular):**
```cpp
class Adder8 : public IOComponent {
    Adder8() : IOComponent("ADD8", [](IOComponent* self) {
        // 8 individual input pins for A
        for (int i = 0; i < 8; i++) {
            self->addPin("A" + std::to_string(i), PinType::INPUT);
            self->addPin("B" + std::to_string(i), PinType::INPUT);
            self->addPin("S" + std::to_string(i), PinType::OUTPUT);
        }
        self->addPin("Cin", PinType::INPUT);
        self->addPin("Cout", PinType::OUTPUT);
    }) {}

    void buildInternals(ComponentBuilder& builder) override {
        // 8 full adders with carry chain
        for (int i = 0; i < 8; i++) {
            builder.addNewComponent<FullAdder>("FA" + std::to_string(i));
        }
        // ... 24+ wire connections (verbose!)
    }
};

// Usage:
auto adder = Component::create<Adder8>("ADD");
for (int i = 0; i < 8; i++) {
    // 8 separate wire connections for A bus
    builder.addNewWire("A" + std::to_string(i), ...);
}
```

**Option C (Hybrid - External BusPin, Internal Gates):**
```cpp
class Adder8 : public IOComponent {
    Adder8() : IOComponent("ADD8", [](IOComponent* self) {
        // Clean external interface
        self->addBusPin("A", PinType::INPUT, 8);
        self->addBusPin("B", PinType::INPUT, 8);
        self->addBusPin("S", PinType::OUTPUT, 8);
        self->addPin("Cin", PinType::INPUT);
        self->addPin("Cout", PinType::OUTPUT);
    }) {}

    void buildInternals(ComponentBuilder& builder) override {
        // Unpack input buses to individual bits
        auto unpacker_a = builder.addNewComponent<BusUnpacker<8>>("UNPACK_A");
        auto unpacker_b = builder.addNewComponent<BusUnpacker<8>>("UNPACK_B");
        builder.connectBusPin(getInputBusPin("A"), unpacker_a->getInput());
        builder.connectBusPin(getInputBusPin("B"), unpacker_b->getInput());

        // Internal gate-level logic (8 full adders)
        for (int i = 0; i < 8; i++) {
            auto fa = builder.addNewComponent<FullAdder>("FA" + std::to_string(i));
            builder.connectBit(unpacker_a->getBit(i), fa->getInputPin("A"));
            builder.connectBit(unpacker_b->getBit(i), fa->getInputPin("B"));
        }

        // Pack output bits back to bus
        auto packer = builder.addNewComponent<BusPacker<8>>("PACK_S");
        builder.connectBusPin(packer->getOutput(), getOutputBusPin("S"));
    }
};

// Usage (much cleaner!):
auto adder = Component::create<Adder8>("ADD");
builder.connectBusWire(data_bus_a, adder->getBusPin("A"));  // Single connection!
```

---

### Example 2: 32-bit ALU (CPU-Level)

**Option B/C (Bus-Granular):**
```cpp
class ALU32 : public BasicComponent {
    ALU32() : BasicComponent("ALU32", 3, [](IOComponent* self) {
        self->addBusPin("A", PinType::INPUT, 32);
        self->addBusPin("B", PinType::INPUT, 32);
        self->addBusPin("Y", PinType::OUTPUT, 32);
        self->addPin("OP0", PinType::INPUT);  // Operation select
        self->addPin("OP1", PinType::INPUT);
    }) {}

    void evaluate(size_t time, Simulator& sim) override {
        uint32_t a = getInputBusPin<32>("A")->getValue();
        uint32_t b = getInputBusPin<32>("B")->getValue();
        uint32_t result = 0;

        uint8_t op = (getInputPin("OP1")->getValue() == HIGH ? 2 : 0) +
                     (getInputPin("OP0")->getValue() == HIGH ? 1 : 0);

        switch (op) {
            case 0: result = a + b; break;  // ADD
            case 1: result = a - b; break;  // SUB
            case 2: result = a & b; break;  // AND
            case 3: result = a | b; break;  // OR
        }

        getOutputBusPin<32>("Y")->setValue(result);
    }
};

// Usage (extremely clean!):
auto alu = Component::create<ALU32>("ALU");
builder.connectBusWire(reg_a_bus, alu->getBusPin("A"));
builder.connectBusWire(reg_b_bus, alu->getBusPin("B"));
builder.connectBusWire(result_bus, alu->getBusPin("Y"));
```

**Option A (Bit-Granular) - Would require 96 pins and 96 wire connections!** ❌ Impractical

---

## 7. Performance Analysis

### Simulation Event Counts (32-bit Addition)

| Model | Events per Operation | Event Queue Size | Relative Speed |
|-------|---------------------|------------------|----------------|
| **Bit-Granular (32 pins)** | 64 events (32 bits × 2 wires) | Large | 1x (baseline) |
| **Bus-Granular (1 pin)** | 2 events (1 wire) | Small | **32x faster** |
| **Hybrid (auto-optimized)** | 2-64 events (adaptive) | Medium | **10-30x faster** |

### Memory Footprint (32-bit Register File, 32 registers)

| Model | Pin Count | Wire Count | Memory Usage |
|-------|-----------|------------|--------------|
| **Bit-Granular** | 2048 pins (32 regs × 32 bits × 2) | 2048 wires | ~500 KB |
| **Bus-Granular** | 64 pins (32 regs × 2) | 64 wires | ~20 KB |
| **Hybrid** | 64 BusPins + internal bit-level | Variable | ~50 KB |

**Conclusion**: Bus-granular is 25x more efficient for memory footprint!

---

## 8. Final Recommendation

### Start with Option A, Migrate to Option C

**Months 1-3**: **Option A (Bit-Granular)**
- Reason: Quick to implement, no breaking changes
- Build: Basic gates, 8-bit components, simple ALU
- Accept: Verbosity and slower simulation

**Months 4-6**: **Add Option C (Hybrid)**
- Reason: Enable efficient 32-bit CPU design
- Add: BusWire, BusPin classes (parallel to Wire, Pin)
- Build: 32-bit ALU, register file, memory interface
- Strategy: BusWire for data paths, Wire for control signals

**Months 7+**: **Optimize Hybrid**
- Auto-conversion at boundaries
- Adaptive simulation granularity
- Profiling-driven optimization

### Decision Criteria

Use **Bit-Granular (Option A)** when:
- Component has ≤ 8 bits
- Educational value in seeing individual bits
- Gate-level implementation (adders, shifters)
- Timing precision matters

Use **Bus-Granular (Option C)** when:
- Component has ≥ 16 bits
- Functional/behavioral model
- CPU-level components (ALU, registers, memory)
- Performance critical

---

## 9. Action Items

### Immediate (Week 1):
1. Implement `Bus<WIDTH>` as bit-granular container (Option A)
2. Create ComponentBuilder helper functions to reduce verbosity
3. Write tests: BusTest, BusSliceTest, Adder8BitTest
4. Document limitations clearly

### Near-Term (Months 2-3):
1. Build several components with bit-granular buses
2. Measure performance bottlenecks
3. Identify pain points in API verbosity
4. Prepare design for BusWire addition

### Long-Term (Months 4+):
1. Design BusWire/BusPin API
2. Implement BusPacker/Unpacker
3. Migrate CPU components to bus-granular
4. Benchmark performance improvements

---

## 10. Open Questions for Discussion

1. **Pin naming convention**: `D0, D1, D2` vs `D[0], D[1], D[2]`?
2. **Bus slicing syntax**: How to specify `bus[15:8]` in C++?
3. **Visualization**: Show individual bits or aggregated hex value?
4. **Python bindings**: Expose bit-level or bus-level API?
5. **Timing model**: Should bus bits have independent delays or synchronized?

---

**Document Status**: Draft for review
**Author**: Design discussion with Claude
**Date**: 2025-12-31
**Next Review**: After Phase 1 implementation (Month 3)

1. I want both `Wire` and `Wire<n>`, just like verilog.
2. I choose option C, but instead of packer and unpacker, I want to make a rewiring component, it gets wires/bus wires as input, and wire/bus wires with the same number of bits as output. There is a one-to-one matching in the rewire component, so that it can both act as a packer and unpacker.

Afterwards, make a document if and only if I explicitly tell you to do so.
Remember this, put it in CLAUDE.md.

For this section, use wire-template-implementation-plan as source of truth, update it whenever our plan is changed.

1. For the event model, let's make the wire fire one event.
2. For the rewiring component, will it be better to ease the one-to-one condition? I think for each output bit, only one/zero input bit need to be specified, we will ignore dangling input bits, and pump UNKNOWN for dangling output bits. Evaluate this over the previous model.